#!/usr/bin/env bash
# =============================================================================
# Cyberdeck Military Comms Suite v9 — Full Pi Installer / Updater
#
# INSTALL (one of):
#   bash install.sh                          from extracted zip / git clone
#   bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/cyberdeck/main/install.sh)
#   git clone https://github.com/YOUR_USERNAME/cyberdeck && bash cyberdeck/install.sh
#
# UPDATE (one of):
#   cyberdeck --update                       from anywhere after install
#   bash install.sh                          re-run from project directory
#
# UNINSTALL:
#   rm -rf ~/.local/share/cyberdeck ~/.local/bin/cyberdeck
#   rm -f  ~/.local/share/applications/cyberdeck.desktop ~/Desktop/Cyberdeck.desktop
# =============================================================================

set -euo pipefail

GRN='\033[0;32m'; AMB='\033[0;33m'; RED='\033[0;31m'; DIM='\033[2m'; NC='\033[0m'
ok()   { echo -e "${GRN}  [OK]${NC}   $*"; }
warn() { echo -e "${AMB}  [!!]${NC}   $*"; }
info() { echo -e "${DIM}  -->  ${NC}$*"; }
fail() { echo -e "${RED}  [FAIL]${NC} $*"; exit 1; }

REPO_URL="https://github.com/YOUR_USERNAME/cyberdeck"
INSTALL_DIR="$HOME/.local/share/cyberdeck"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"
DESKTOP_DIR="$HOME/Desktop"
CMD="$BIN_DIR/cyberdeck"

echo ""
echo "============================================="
echo "  CYBERDECK v9 — INSTALL / UPDATE"
echo "============================================="

# ── Detect source: local clone/zip OR piped from curl ─────────────────────────
# BASH_SOURCE[0] is "-" or "/dev/stdin" when piped from curl
if [[ "${BASH_SOURCE[0]}" == "-" ]] || [[ "${BASH_SOURCE[0]}" == "/dev/stdin" ]]; then
    CURL_MODE=1
    info "Running via curl — will install from pip/git"
else
    CURL_MODE=0
    SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    info "Local source: $SRC"
fi

echo "  Install : $INSTALL_DIR"
echo "  Command : cyberdeck"
echo "============================================="
echo ""

# ── 1. System packages ────────────────────────────────────────────────────────
echo "[ 1 / 7 ]  System packages"
if command -v apt-get &>/dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq \
        python3-pyqt5 \
        python3-serial \
        python3-pip \
        python3-pynmea2 \
        git \
        libxcb-xinerama0 \
        libxcb-cursor0 2>/dev/null || true
    ok "apt packages installed"
else
    warn "apt-get not found — skipping (non-Debian system)"
fi

# ── 2. Python package from pip / git ─────────────────────────────────────────
echo ""
echo "[ 2 / 7 ]  Python packages"
PIP_FLAGS="--quiet --break-system-packages"
PIP_FALLBACK="--quiet"

if [ "$CURL_MODE" -eq 1 ]; then
    # No local source — install the Python package directly from git
    info "Installing cyberdeck-milcomms[pi] from GitHub..."
    python3 -m pip install $PIP_FLAGS \
        "cyberdeck-milcomms[pi] @ git+${REPO_URL}.git" 2>/dev/null \
        || python3 -m pip install $PIP_FALLBACK \
        "cyberdeck-milcomms[pi] @ git+${REPO_URL}.git" 2>/dev/null \
        || fail "pip install from git failed — check internet connection and repo URL"
    ok "cyberdeck-milcomms installed from git"
else
    # Local source available — install editable so changes take effect immediately
    python3 -m pip install $PIP_FLAGS pycryptodome pynmea2 pyserial 2>/dev/null \
        || python3 -m pip install $PIP_FALLBACK pycryptodome pynmea2 pyserial 2>/dev/null \
        || warn "Some Python packages failed — COMSEC/GPS may not work"
    ok "Python packages ready"
fi

# ── 3. Serial / dialout group ─────────────────────────────────────────────────
echo ""
echo "[ 3 / 7 ]  Serial port access"
if groups | grep -q dialout; then
    ok "$USER already in dialout group"
else
    sudo usermod -aG dialout "$USER"
    warn "$USER added to dialout — re-login required for serial access"
fi

# ── 4. GPS UART (Raspberry Pi only) ───────────────────────────────────────────
echo ""
echo "[ 4 / 7 ]  GPS UART"
BOOT_CFG=""
for f in /boot/firmware/config.txt /boot/config.txt; do
    [ -f "$f" ] && BOOT_CFG="$f" && break
done
if [ -n "$BOOT_CFG" ]; then
    if ! grep -q "enable_uart=1" "$BOOT_CFG"; then
        echo "enable_uart=1" | sudo tee -a "$BOOT_CFG" > /dev/null
        warn "enable_uart=1 added to $BOOT_CFG — reboot required for GPS"
    else
        ok "UART already enabled"
    fi
    if command -v raspi-config &>/dev/null; then
        CONS="$(sudo raspi-config nonint get_serial_cons 2>/dev/null || echo 1)"
        if [ "$CONS" = "0" ]; then
            sudo raspi-config nonint do_serial 1 2>/dev/null || true
            ok "Serial console disabled — ttyAMA0 freed for GPS"
        else
            ok "Serial console already disabled"
        fi
    fi
else
    info "No Pi boot config found — skipping UART setup"
fi

# ── 5. Install / update application files ─────────────────────────────────────
echo ""
echo "[ 5 / 7 ]  Application files"
mkdir -p "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR/arduino"

if [ "$CURL_MODE" -eq 0 ]; then
    # Local source: copy Python files from rpi/ or cyberdeck/ subdir
    PY_SRC=""
    [ -d "$SRC/cyberdeck" ] && PY_SRC="$SRC/cyberdeck"
    [ -d "$SRC/rpi"       ] && PY_SRC="$SRC/rpi"
    [ -z "$PY_SRC" ] && fail "Cannot find Python source directory in $SRC"

    cp -f "$PY_SRC/app.py"            "$INSTALL_DIR/"
    cp -f "$PY_SRC/serial_modem.py"   "$INSTALL_DIR/"
    cp -f "$PY_SRC/crypto_manager.py" "$INSTALL_DIR/"
    cp -f "$PY_SRC/gps_reader.py"     "$INSTALL_DIR/"

    # Arduino firmware
    for ino in "$SRC/arduino/"*.ino; do
        [ -f "$ino" ] && cp -f "$ino" "$INSTALL_DIR/arduino/"
    done

    ok "Files copied from local source"
else
    # Curl mode: Python package already installed via pip above.
    # Find the installed package location to get app.py path.
    PKG_DIR="$(python3 -c 'import cyberdeck; import os; print(os.path.dirname(cyberdeck.__file__))' 2>/dev/null || true)"
    if [ -n "$PKG_DIR" ] && [ -d "$PKG_DIR" ]; then
        cp -f "$PKG_DIR/app.py"            "$INSTALL_DIR/"
        cp -f "$PKG_DIR/serial_modem.py"   "$INSTALL_DIR/"
        cp -f "$PKG_DIR/crypto_manager.py" "$INSTALL_DIR/"
        cp -f "$PKG_DIR/gps_reader.py"     "$INSTALL_DIR/"
        ok "Files copied from installed pip package"
    else
        warn "Could not locate installed package — launcher will use pip package directly"
    fi
fi

# Save this installer for `cyberdeck --update`
if [ "$CURL_MODE" -eq 0 ]; then
    cp -f "${BASH_SOURCE[0]}" "$INSTALL_DIR/install.sh"
else
    # Download a fresh copy of install.sh for future --update runs
    curl -fsSL "${REPO_URL}/raw/main/install.sh" -o "$INSTALL_DIR/install.sh" 2>/dev/null \
        || warn "Could not save install.sh for --update (no internet?)"
fi
chmod +x "$INSTALL_DIR/install.sh" 2>/dev/null || true

# ── 6. Terminal command ───────────────────────────────────────────────────────
echo ""
echo "[ 6 / 7 ]  Terminal command"
mkdir -p "$BIN_DIR"

cat > "$CMD" << 'WRAPPER'
#!/usr/bin/env bash
# cyberdeck — Cyberdeck Milcomms v9 launcher
# Auto-generated by install.sh — re-run install.sh or use --update to refresh.

INSTALL_DIR="$HOME/.local/share/cyberdeck"

# --update: re-run the saved installer
if [[ "${1:-}" == "--update" ]]; then
    echo "Cyberdeck: running updater..."
    exec bash "$INSTALL_DIR/install.sh"
fi

export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb}"
export QT_AUTO_SCREEN_SCALE_FACTOR=0

# Prefer installed copy; fall back to the pip-installed package
if [ -f "$INSTALL_DIR/app.py" ]; then
    exec python3 "$INSTALL_DIR/app.py" "$@"
else
    exec python3 -m cyberdeck "$@"
fi
WRAPPER

chmod +x "$CMD"
ok "Command: $CMD"

# Add ~/.local/bin to PATH in .bashrc if not already present
if ! grep -qxF 'export PATH="$HOME/.local/bin:$PATH"' "$HOME/.bashrc" 2>/dev/null; then
    if ! echo "$PATH" | grep -q "$HOME/.local/bin"; then
        {
            echo ""
            echo "# Added by Cyberdeck installer"
            echo 'export PATH="$HOME/.local/bin:$PATH"'
        } >> "$HOME/.bashrc"
        warn "Added ~/.local/bin to PATH in ~/.bashrc"
        warn "Run: source ~/.bashrc  to use 'cyberdeck' in this terminal now"
    fi
else
    ok "~/.local/bin already in .bashrc"
fi

# ── 7. Desktop icon ───────────────────────────────────────────────────────────
echo ""
echo "[ 7 / 7 ]  Desktop icon"

ICON_PATH="$INSTALL_DIR/cyberdeck.svg"
cat > "$ICON_PATH" << 'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="6" fill="#020902"/>
  <rect x="4"  y="4"  width="56" height="44" rx="4" fill="#040c04" stroke="#0d2d0d" stroke-width="1.5"/>
  <rect x="8"  y="10" width="20" height="2.5" rx="1" fill="#2eff2e" opacity="0.9"/>
  <rect x="8"  y="16" width="32" height="2.5" rx="1" fill="#2eff2e" opacity="0.7"/>
  <rect x="8"  y="22" width="26" height="2.5" rx="1" fill="#2eff2e" opacity="0.7"/>
  <rect x="8"  y="28" width="36" height="2.5" rx="1" fill="#2eff2e" opacity="0.7"/>
  <rect x="8"  y="34" width="16" height="2.5" rx="1" fill="#2eff2e" opacity="0.9"/>
  <rect x="26" y="34" width="5"  height="2.5" rx="0.5" fill="#2eff2e"/>
  <rect x="28" y="48" width="8"  height="5"   rx="1" fill="#0d2d0d"/>
  <rect x="20" y="53" width="24" height="3"   rx="2" fill="#0d2d0d"/>
  <line x1="48" y1="4" x2="44" y2="14" stroke="#1ab81a" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="48" cy="4" r="1.5" fill="#2eff2e"/>
  <rect x="44" y="38" width="14" height="10" rx="2" fill="#071207" stroke="#1ab81a" stroke-width="1"/>
  <rect x="47" y="34" width="8"  height="6"  rx="4" fill="none"    stroke="#1ab81a" stroke-width="1.5"/>
  <rect x="49.5" y="41" width="3" height="3" rx="0.5" fill="#2eff2e"/>
</svg>
SVG

ok "Icon: $ICON_PATH"

DESKTOP_CONTENT="[Desktop Entry]
Version=1.0
Type=Application
Name=Cyberdeck Milcomms
GenericName=Encrypted Radio Terminal
Comment=PMR446 encrypted radio messenger — ChaCha20 / RTTY
Exec=$CMD %u
Icon=$ICON_PATH
Terminal=false
StartupNotify=true
Categories=HamRadio;Network;
Keywords=radio;crypto;rtty;comms;pmr446;
"

mkdir -p "$APPS_DIR"
printf '%s' "$DESKTOP_CONTENT" > "$APPS_DIR/cyberdeck.desktop"
chmod +x "$APPS_DIR/cyberdeck.desktop"
ok "App menu: $APPS_DIR/cyberdeck.desktop"

mkdir -p "$DESKTOP_DIR"
printf '%s' "$DESKTOP_CONTENT" > "$DESKTOP_DIR/Cyberdeck.desktop"
chmod +x "$DESKTOP_DIR/Cyberdeck.desktop"
gio set "$DESKTOP_DIR/Cyberdeck.desktop" metadata::trusted true 2>/dev/null || true
gvfs-set-attribute "$DESKTOP_DIR/Cyberdeck.desktop" \
    metadata::trusted true 2>/dev/null || true
ok "Desktop: $DESKTOP_DIR/Cyberdeck.desktop"

update-desktop-database "$APPS_DIR" 2>/dev/null || true
xdg-desktop-menu forceupdate 2>/dev/null || true

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo -e "  ${GRN}DONE${NC}"
echo "============================================="
echo ""
echo "  TERMINAL COMMANDS:"
echo -e "    ${GRN}cyberdeck${NC}                       launch"
echo -e "    ${GRN}cyberdeck --update${NC}              update in-place"
echo -e "    ${GRN}cyberdeck --reset${NC}               wipe settings + key"
echo -e "    ${GRN}cyberdeck --display 35inch${NC}      force 3.5\" layout"
echo -e "    ${GRN}cyberdeck --port /dev/ttyACM1${NC}   port override"
echo ""
echo "  DESKTOP ICON:  ~/Desktop/Cyberdeck.desktop"
echo "  (if LXDE shows 'untrusted': right-click > Allow Launching)"
echo ""
echo "  ARDUINO FIRMWARE:"
echo "    $INSTALL_DIR/arduino/cyberdeck_v7.ino"
echo "    Board: SparkFun Pro Micro  ATmega32U4  5V / 16MHz"
echo ""
! groups | grep -q dialout && \
    echo -e "  ${AMB}[!!]${NC} Re-login required for serial port access" && echo ""
! echo "$PATH" | grep -q "$HOME/.local/bin" && \
    echo -e "  ${AMB}[!!]${NC} Run: source ~/.bashrc  to activate 'cyberdeck' now" && echo ""
