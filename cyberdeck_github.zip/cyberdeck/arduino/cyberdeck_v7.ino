/*
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║  Cyberdeck Military Comms Suite — Firmware v7.3                         ║
 * ║  Target: SparkFun Pro Micro (ATmega32U4, 5V, 16MHz)                     ║
 * ╠═══════════════════════════════════════════════════════════════════════════╣
 * ║  PACKET FORMAT v2                                                         ║
 * ║  [48×0xAA preamble] [0x7E 0x7E sync]                                    ║
 * ║  [NETID:1] [FLAGS:1] [SEQ:2 big-endian] [LEN:1] [payload:LEN] [CRC:2]  ║
 * ║  [5×0xAA tail]                                                            ║
 * ║                                                                           ║
 * ║  FLAGS byte:                                                              ║
 * ║    bits 7-6  PRIORITY  0=ROUTINE 1=PRIORITY 2=IMMEDIATE 3=FLASH         ║
 * ║    bit  5    ACK_REQ   sender requests acknowledgement                   ║
 * ║    bit  4    IS_ACK    this packet is an ACK                             ║
 * ║    bit  3    IS_DUMMY  dummy/filler traffic — Pi may discard             ║
 * ║    bit  2    PADDED    payload is prefixed with 1-byte true_len          ║
 * ║    bits 1-0  reserved                                                    ║
 * ║                                                                           ║
 * ║  ACK payload:  2 bytes = SEQ being acknowledged (big-endian)            ║
 * ║  Padded payload: [true_len:1][data:true_len][random fill...]             ║
 * ║                                                                           ║
 * ║  COMMANDS  Pi → Arduino (9600 baud, newline-terminated)                  ║
 * ║  TX:<flags_hex2>:<payload_hex>    (flags+payload in one atomic command)  ║
 * ║  TXOPT:<hexbyte>  (deprecated — flags now embedded in TX)                ║
 * ║  PING    KEY:1/KEY:0    BAUD:<50|100>    NETID:<hexbyte>                 ║
 * ║  EMCON:<0|1>  BEACON:<0|1>  DUMMY:<0|1>  JITTER:<0|1>  STATUS          ║
 * ║  ZEROIZE  (emergency operational reset)                               ║
 * ║                                                                           ║
 * ║  RESPONSES  Arduino → Pi                                                  ║
 * ║  READY  PONG  RX:<flags>:<seq4>:<hex>  RSSI:<0-100>  TXSTART:<s>       ║
 * ║  TXDONE  ACK:<seq4>  RETRY:<seq4>:<n>  FAIL:<seq4>  LBT:BUSY           ║
 * ║  STATUS:<k=v;…>  DBG:<text>                                              ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 *
 * v7.1 optimisations vs v7:
 *   - Non-blocking LBT: reads ISR-accumulated lbt_edges_last (no 20ms spin)
 *   - pkt_ready race fixed: cli/sei atomic copy, no copy-back
 *   - dummy_pump respects EMCON
 *   - ticks_per_bit / edge_threshold / bit_period_ms marked volatile
 *   - Single unhex() replaces 3 duplicate lambdas in parse_cmd()
 *   - TX_HDR macro replaces [&]-capture lambda in tx_build()
 *   - tx_buf_len / tx_buf_pos → uint8_t (max frame 190 B < 255)
 *   - pri_str moved to PROGMEM (saves 40 bytes RAM)
 *
 * v7.2 bug fixes vs v7.1 (sanity check pass):
 *   BUG1  PADDED guard: > PADDED_LEN → >= PADDED_LEN
 *         (plen=128 wrote 129 bytes, corrupting every max-size padded packet)
 *   BUG2  ARQ seq race: arq_seq/arq_timer now set at actual TX, not tx_initiate
 *         (jitter window allowed tx_send_ack to shift tx_seq, arq_seq mismatch
 *          → remote ACK never matched → silent RETRY×3 → FAIL on all jitter+ARQ TX)
 *   BUG3  ARQ timer: resets at actual TX start not tx_initiate
 *         (jitter delay was eating into ACK timeout window)
 *   BUG4  Stack: TX decode buffer static (was 128-byte stack frame in parse_cmd)
 *   BUG5  memcpy: uses rx_snap_len not volatile pkt_len
 *   BUG6  RSSI: computed from lbt_edges_last, not hardcoded 90
 *   BUG7  BAUD: warns if changed mid-packet (pkt_state != PS_IDLE)
 *
 * v7.3 logic fixes (deep audit pass):
 *   BUGA  jitter_armed double-send: arq_pump now clears jitter_armed before
 *         retransmitting.  Previously every ARQ retry sent TWO packets:
 *         one from arq_pump and one from the still-armed jitter_pump.
 *   BUGB  tx_send_ack bypassed LBT: added inline lbt_edges_last check.
 *         ACK is silently dropped on busy channel; remote ARQ retries and
 *         we re-ACK the copy.  Prevents collision without LBT:BUSY noise.
 *   BUGC  dummy_pump reset timer before EMCON check: emcon added to early-out
 *         guard.  Previously EMCON periods silently extended dummy intervals
 *         by DUMMY_INTERVAL per blocked attempt.
 *
 * v7.3 logical fixes (deep audit pass):
 *   L1  arq_pending set before LBT check (CRITICAL)
 *       Setting arq_pending=true before lbt_busy() left arq_timer=0 on LBT
 *       rejection. arq_pump fired after 5 s uptime, retransmitting the
 *       LBT-dropped frame unsolicited (×ARQ_RETRIES then FAIL).
 *       Fix: arq_pending/arq_seq/arq_timer committed only after LBT passes
 *       in both direct and jitter paths.
 *   L2  RETRY: reported pre-update arq_seq (Pi saw mismatched RETRY/ACK SEQs)
 *       Fix: RETRY: printed after arq_seq = tx_seq.
 *   L4  tx_send_ack: defensive tx_active guard added.
 *   L5  lfsr_byte: uint16_t bit → uint8_t (1-bit value on AVR hot path).
 */

#include <avr/pgmspace.h>

// ── Compile-time configuration ────────────────────────────────────────────────
#define LOOPBACK_TEST              // comment out for real radio
// #define DEBUG_BYTES             // print bytes entering packet SM (keep OFF during TX)

#define CW_CALLSIGN    "CDECK"    // callsign sent in CW beacon
#define DEFAULT_NETID   0xCD      // net ID byte — foreign packets are dropped
#define PADDED_LEN      128       // fixed payload length when PADDED flag is set
#define ARQ_RETRIES     3         // max retransmit attempts before FAIL
#define ARQ_TIMEOUT_MS  5000UL    // ms to wait for ACK before retry
#define DUMMY_INTERVAL  60000UL   // ms between dummy traffic transmissions
#define CW_DIT_MS       100       // CW dit duration (ms); dah=3×

// ── RTTY parameters ───────────────────────────────────────────────────────────
#define MARK_HZ   1000
#define SPACE_HZ  2000
// Timer4 phase-correct PWM (prescaler=1): f = F_CPU / (2*(OCR4A+1))
#define OCR_MARK  7999   // 16e6/(2*1000) − 1
#define OCR_SPACE 3999   // 16e6/(2*2000) − 1

// ── Pins ──────────────────────────────────────────────────────────────────────
#define TX_PIN   6    // PD7 — Timer4 OC4A — audio out to radio MIC-IN
#define RX_PIN   3    // PD0 — audio in from radio SPKR+
#define RX_LED  17    // active LOW

// ── Packet framing ────────────────────────────────────────────────────────────
#define PREAMBLE_BYTE  0xAA
#define PREAMBLE_MIN   8
#define SYNC_BYTE      0x7E
#define MAX_PAYLOAD    160        // max received payload bytes (> PADDED_LEN)

// ── FLAGS byte bit masks ──────────────────────────────────────────────────────
#define F_PRI_MASK  0xC0
#define F_PRI_SHIFT 6
#define F_ACK_REQ   0x20
#define F_IS_ACK    0x10
#define F_IS_DUMMY  0x08
#define F_PADDED    0x04

#define PRI_ROUTINE   0
#define PRI_PRIORITY  1
#define PRI_IMMEDIATE 2
#define PRI_FLASH     3

// ── TX buffer (max frame = 48+2+5+128+2+5 = 190 B — fits uint8_t) ───────────
#define TX_BUF_SIZE 220
static uint8_t  tx_buf[TX_BUF_SIZE];
static uint8_t  tx_buf_len  = 0;
static uint8_t  tx_buf_pos  = 0;
static uint8_t  tx_bit_idx  = 0;
static bool     tx_active   = false;
static uint32_t tx_bit_timer = 0;

// ── Baud config — volatile because ISR reads these ───────────────────────────
static volatile uint8_t ticks_per_bit  = 20;  // 50 baud: 20 ticks @ 1 kHz
static volatile uint8_t edge_threshold = 30;
static volatile uint8_t bit_period_ms  = 20;

// ── RX ISR state ──────────────────────────────────────────────────────────────
volatile uint8_t  edge_count     = 0;
volatile uint8_t  lbt_edges_last = 0;   // last completed bit-period edge count
volatile uint8_t  tick_count     = 0;
volatile uint16_t uart_win       = 0;
volatile uint8_t  uart_bits_n    = 0;

// ── RX packet state machine ───────────────────────────────────────────────────
enum PktState {
  PS_IDLE, PS_PREAMBLE, PS_SYNC1,
  PS_NETID, PS_FLAGS, PS_SEQ_HI, PS_SEQ_LO, PS_LEN,
  PS_DATA, PS_CRC_HI, PS_CRC_LO
};
volatile PktState pkt_state   = PS_IDLE;
volatile uint8_t  pkt_pre_cnt = 0;
volatile uint8_t  pkt_netid   = 0;
volatile uint8_t  pkt_flags   = 0;
volatile uint16_t pkt_seq     = 0;
volatile uint8_t  pkt_len     = 0;
volatile uint8_t  pkt_pos     = 0;
volatile uint16_t pkt_crc_acc = 0;
volatile uint8_t  pkt_buf[MAX_PAYLOAD + 2];
volatile bool     pkt_ready   = false;

// Double-buffer: ISR writes to pkt_buf/pkt_{netid,flags,seq,len};
// loop() atomically snapshots into rx_snap_* before releasing pkt_ready.
static uint8_t  rx_snap_netid = 0;
static uint8_t  rx_snap_flags = 0;
static uint16_t rx_snap_seq   = 0;
static uint8_t  rx_snap_len   = 0;
static uint8_t  rx_snap_buf[MAX_PAYLOAD];
static bool     rx_snap_ready = false;

// ── TX options & sequence ─────────────────────────────────────────────────────
static uint8_t  txopt   = 0;
static uint16_t tx_seq  = 0;

// ── ARQ ───────────────────────────────────────────────────────────────────────
static bool     arq_pending      = false;
static uint8_t  arq_retries_left = 0;
static uint32_t arq_timer        = 0;
static uint16_t arq_seq          = 0;
static uint8_t  arq_payload[PADDED_LEN + 8];
static uint8_t  arq_payload_len  = 0;
static uint8_t  arq_flags_saved  = 0;

// ── TX jitter ─────────────────────────────────────────────────────────────────
static bool     jitter_en    = false;
static bool     jitter_armed = false;
static uint32_t jitter_timer = 0;
static uint16_t jitter_ms    = 0;

// ── System flags ──────────────────────────────────────────────────────────────
static bool     emcon      = false;
static uint8_t  net_id     = DEFAULT_NETID;
static bool     dummy_en   = false;
static uint32_t dummy_timer = 0;

// ── LFSR (Galois 16-bit) ──────────────────────────────────────────────────────
static uint16_t lfsr_state = 0xACE1;

static uint8_t lfsr_byte() {
  uint8_t b = 0;
  for (uint8_t i = 0; i < 8; i++) {
    uint8_t bit = ((lfsr_state ^ (lfsr_state >> 2) ^
                    (lfsr_state >> 3) ^ (lfsr_state >> 5))) & 1;
    lfsr_state = (lfsr_state >> 1) | (bit << 15);
    b = (b >> 1) | (uint8_t)(bit << 7);
  }
  return b;
}

// ── CW beacon ─────────────────────────────────────────────────────────────────
static bool morse_key_down = false;
static bool beacon_en      = false;

// Morse table in PROGMEM
static const char CW_A[] PROGMEM = ".-";
static const char CW_B[] PROGMEM = "-...";
static const char CW_C[] PROGMEM = "-.-.";
static const char CW_D[] PROGMEM = "-..";
static const char CW_E[] PROGMEM = ".";
static const char CW_F[] PROGMEM = "..-.";
static const char CW_G[] PROGMEM = "--.";
static const char CW_H[] PROGMEM = "....";
static const char CW_I[] PROGMEM = "..";
static const char CW_J[] PROGMEM = ".---";
static const char CW_K[] PROGMEM = "-.-";
static const char CW_L[] PROGMEM = ".-..";
static const char CW_M[] PROGMEM = "--";
static const char CW_N[] PROGMEM = "-.";
static const char CW_O[] PROGMEM = "---";
static const char CW_P[] PROGMEM = ".--.";
static const char CW_Q[] PROGMEM = "--.-";
static const char CW_R[] PROGMEM = ".-.";
static const char CW_S[] PROGMEM = "...";
static const char CW_T[] PROGMEM = "-";
static const char CW_U[] PROGMEM = "..-";
static const char CW_V[] PROGMEM = "...-";
static const char CW_W[] PROGMEM = ".--";
static const char CW_X[] PROGMEM = "-..-";
static const char CW_Y[] PROGMEM = "-.--";
static const char CW_Z[] PROGMEM = "--..";
static const char CW_0[] PROGMEM = "-----";
static const char CW_1[] PROGMEM = ".----";
static const char CW_2[] PROGMEM = "..---";
static const char CW_3[] PROGMEM = "...--";
static const char CW_4[] PROGMEM = "....-";
static const char CW_5[] PROGMEM = ".....";
static const char CW_6[] PROGMEM = "-....";
static const char CW_7[] PROGMEM = "--...";
static const char CW_8[] PROGMEM = "---..";
static const char CW_9[] PROGMEM = "----.";

static const char * const CW_TABLE[36] PROGMEM = {
  CW_A, CW_B, CW_C, CW_D, CW_E, CW_F, CW_G, CW_H, CW_I, CW_J,
  CW_K, CW_L, CW_M, CW_N, CW_O, CW_P, CW_Q, CW_R, CW_S, CW_T,
  CW_U, CW_V, CW_W, CW_X, CW_Y, CW_Z,
  CW_0, CW_1, CW_2, CW_3, CW_4, CW_5, CW_6, CW_7, CW_8, CW_9
};

// Priority strings in PROGMEM — saves 40 bytes RAM vs static local char array
static const char PRI_0[] PROGMEM = "ROUTINE";
static const char PRI_1[] PROGMEM = "PRIORITY";
static const char PRI_2[] PROGMEM = "IMMEDIATE";
static const char PRI_3[] PROGMEM = "FLASH";
static const char * const PRI_STRS[4] PROGMEM = {PRI_0, PRI_1, PRI_2, PRI_3};

#define CW_MSG_LEN 32
static char cw_msg[CW_MSG_LEN];

enum CwState { CW_IDLE, CW_TONE_ON, CW_TONE_OFF };
static CwState  cw_sm       = CW_IDLE;
static uint32_t cw_timer    = 0;
static uint16_t cw_duration = 0;
static uint8_t  cw_char_idx = 0;
static uint8_t  cw_elem_idx = 0;
static char     cw_pattern[8] = {};

// ── CRC-16/CCITT ──────────────────────────────────────────────────────────────
static inline uint16_t crc16(uint16_t crc, uint8_t b) {
  crc ^= (uint16_t)b << 8;
  for (uint8_t i = 0; i < 8; i++)
    crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : (crc << 1);
  return crc;
}

// ── Tone generation (Timer4, PD7) ─────────────────────────────────────────────
static inline void tone_mark()  { TCCR4A=0x42; TCCR4B=0x01; OCR4A=OCR_MARK;  DDRD|=(1<<7); }
static inline void tone_space() { TCCR4A=0x42; TCCR4B=0x01; OCR4A=OCR_SPACE; DDRD|=(1<<7); }
static inline void tone_off()   { TCCR4A=0;    TCCR4B=0;                      DDRD&=~(1<<7); }

// ── Hex utilities ─────────────────────────────────────────────────────────────
static inline uint8_t unhex(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return 0;
}

static void print_hex_byte(uint8_t b) {
  if (b < 0x10) Serial.print('0');
  Serial.print(b, HEX);
}
static void print_hex_word(uint16_t w) { print_hex_byte(w>>8); print_hex_byte(w&0xFF); }

// ── TX_HDR macro — write byte to tx_buf and accumulate CRC ───────────────────
// Uses local variables p (uint8_t&) and crc (uint16_t&) in calling scope.
#define TX_HDR(b) do { uint8_t _b=(uint8_t)(b); tx_buf[p++]=_b; crc=crc16(crc,_b); } while(0)

// ─────────────────────────────────────────────────────────────────────────────
//  Packet push — called from ISR with each decoded byte
// ─────────────────────────────────────────────────────────────────────────────
static void pkt_push(uint8_t b) {
#ifdef DEBUG_BYTES
  extern volatile uint8_t dbg_buf[32];
  extern volatile uint8_t dbg_wr, dbg_rd;
  uint8_t n = (dbg_wr + 1) & 31;
  if (n != dbg_rd) { dbg_buf[dbg_wr] = b; dbg_wr = n; }
#endif

  switch (pkt_state) {
    case PS_IDLE:
      if (b == PREAMBLE_BYTE) { pkt_state = PS_PREAMBLE; pkt_pre_cnt = 1; }
      break;

    case PS_PREAMBLE:
      if      (b == PREAMBLE_BYTE) pkt_pre_cnt++;
      else if (b == SYNC_BYTE && pkt_pre_cnt >= PREAMBLE_MIN) pkt_state = PS_SYNC1;
      else    { pkt_state = PS_IDLE; pkt_pre_cnt = 0; }
      break;

    case PS_SYNC1:
      if      (b == SYNC_BYTE)      pkt_state = PS_NETID;
      else if (b == PREAMBLE_BYTE) { pkt_state = PS_PREAMBLE; pkt_pre_cnt = 1; }
      else     pkt_state = PS_IDLE;
      break;

    case PS_NETID:
      pkt_netid   = b;
      pkt_crc_acc = crc16(0xFFFF, b);
      pkt_state   = PS_FLAGS;
      break;

    case PS_FLAGS:
      pkt_flags   = b;
      pkt_crc_acc = crc16(pkt_crc_acc, b);
      pkt_state   = PS_SEQ_HI;
      break;

    case PS_SEQ_HI:
      pkt_seq     = (uint16_t)b << 8;
      pkt_crc_acc = crc16(pkt_crc_acc, b);
      pkt_state   = PS_SEQ_LO;
      break;

    case PS_SEQ_LO:
      pkt_seq    |= b;
      pkt_crc_acc = crc16(pkt_crc_acc, b);
      pkt_state   = PS_LEN;
      break;

    case PS_LEN:
      if (b == 0 || b > MAX_PAYLOAD) { pkt_state = PS_IDLE; break; }
      pkt_len     = b;
      pkt_pos     = 0;
      pkt_crc_acc = crc16(pkt_crc_acc, b);
      pkt_state   = PS_DATA;
      break;

    case PS_DATA:
      pkt_buf[pkt_pos++] = b;
      pkt_crc_acc = crc16(pkt_crc_acc, b);
      if (pkt_pos >= pkt_len) pkt_state = PS_CRC_HI;
      break;

    case PS_CRC_HI:
      pkt_buf[pkt_pos] = b;   // borrow pkt_buf[pkt_len] as CRC_HI scratch
      pkt_state = PS_CRC_LO;
      break;

    case PS_CRC_LO: {
      uint16_t recv_crc = ((uint16_t)pkt_buf[pkt_pos] << 8) | b;
      if (recv_crc == pkt_crc_acc && !pkt_ready) {
        pkt_ready = true;   // signals loop() to snapshot; ISR won't overwrite once true
      }
      pkt_state = PS_IDLE;
      break;
    }

    default: pkt_state = PS_IDLE; break;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Timer3 ISR — 1 kHz — RX bit clock
// ─────────────────────────────────────────────────────────────────────────────
ISR(TIMER3_COMPA_vect) {
  static uint8_t last_pin = 0;
  uint8_t cur = PIND & 0x01;          // PD0 = RX_PIN
  if (cur != last_pin) { edge_count++; last_pin = cur; }

  if (++tick_count < ticks_per_bit) return;
  tick_count = 0;

  uint8_t ec  = edge_count;
  edge_count  = 0;
  lbt_edges_last = ec;                // expose to loop() for non-blocking LBT

  uint8_t bit = (ec < edge_threshold) ? 1 : 0;  // 1=MARK, 0=SPACE

  uart_win    = (uart_win >> 1) | ((uint16_t)bit << 9);
  uart_bits_n++;
  if (uart_bits_n < 10) return;

  // UART framing: bit0=start(SPACE=0), bit9=stop(MARK=1)
  if ((uart_win & 0x0001) == 0 && (uart_win & 0x0200) != 0) {
    pkt_push((uart_win >> 1) & 0xFF);
    uart_bits_n = 1;
  } else if (uart_bits_n > 20) {
    uart_bits_n = 0;
    uart_win    = 0;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TX packet builder — assembles full RTTY frame into tx_buf[]
// ─────────────────────────────────────────────────────────────────────────────
static void tx_build(const uint8_t* payload, uint8_t len,
                     uint8_t flags, uint16_t seq) {
  uint8_t  p   = 0;
  uint16_t crc = 0xFFFF;

  for (uint8_t i = 0; i < 48; i++) tx_buf[p++] = PREAMBLE_BYTE;
  tx_buf[p++] = SYNC_BYTE;
  tx_buf[p++] = SYNC_BYTE;

  TX_HDR(net_id);
  TX_HDR(flags);
  TX_HDR(seq >> 8);
  TX_HDR(seq & 0xFF);

  if (flags & F_PADDED) {
    TX_HDR(PADDED_LEN);         // LEN field = full padded length
    TX_HDR(len);                // first byte of payload = true_len
    for (uint8_t i = 0; i < len; i++)          TX_HDR(payload[i]);
    for (uint8_t i = len+1; i < PADDED_LEN; i++) TX_HDR(lfsr_byte());
  } else {
    TX_HDR(len);
    for (uint8_t i = 0; i < len; i++) TX_HDR(payload[i]);
  }

  tx_buf[p++] = crc >> 8;
  tx_buf[p++] = crc & 0xFF;
  for (uint8_t i = 0; i < 5; i++) tx_buf[p++] = PREAMBLE_BYTE;

  tx_buf_len  = p;
  tx_buf_pos  = 0;
  tx_bit_idx  = 0;
  tx_active   = true;

  // Estimated duration: p bytes × 10 bits/byte ÷ baud
  uint16_t secs = ((uint16_t)p * 10u) / (bit_period_ms == 10 ? 100u : 50u) + 1u;
  Serial.print(F("TXSTART:")); Serial.println(secs);
  digitalWrite(RX_LED, LOW);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ACK transmit
// ─────────────────────────────────────────────────────────────────────────────
static void tx_send_ack(uint16_t ack_seq) {
  if (emcon) return;
  if (tx_active) return;   // defensive: caller guards this but protect against future paths
#ifndef LOOPBACK_TEST
  // ACK is IMMEDIATE priority but does not bypass LBT (only FLASH does).
  // Silently drop if channel is busy — the remote's ARQ will retry and
  // we will re-ACK the retransmitted copy.  Avoids a collision and avoids
  // spamming LBT:BUSY (which would mislead the Pi into thinking a user
  // TX was blocked rather than an outgoing ACK).
  if (lbt_edges_last > edge_threshold) return;
#endif
  uint8_t buf[2] = { (uint8_t)(ack_seq>>8), (uint8_t)(ack_seq&0xFF) };
  tx_seq++;
  tx_build(buf, 2, (PRI_IMMEDIATE << F_PRI_SHIFT) | F_IS_ACK, tx_seq);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TX bit pump — called every loop() iteration
// ─────────────────────────────────────────────────────────────────────────────
static void tx_pump() {
  if (!tx_active) return;
  uint32_t now = millis();
  if (now - tx_bit_timer < bit_period_ms) return;
  tx_bit_timer = now;

  if (tx_buf_pos >= tx_buf_len) {
    tone_off();
    tx_active = false;
    digitalWrite(RX_LED, HIGH);
    Serial.println(F("TXDONE"));
    return;
  }

  uint8_t bv = tx_buf[tx_buf_pos];
  if      (tx_bit_idx == 0)  tone_space();          // start bit
  else if (tx_bit_idx == 9) { tone_mark(); tx_buf_pos++; tx_bit_idx=0; return; }
  else { ((bv >> (tx_bit_idx-1)) & 1) ? tone_mark() : tone_space(); }
  tx_bit_idx++;
}

// ─────────────────────────────────────────────────────────────────────────────
//  ARQ pump
// ─────────────────────────────────────────────────────────────────────────────
static void arq_pump() {
  if (!arq_pending || tx_active) return;
  if (millis() - arq_timer < ARQ_TIMEOUT_MS) return;

  if (arq_retries_left == 0) {
    Serial.print(F("FAIL:")); print_hex_word(arq_seq); Serial.println();
    arq_pending = false;
    jitter_armed = false;   // ensure no ghost jitter-TX after final failure
    return;
  }
  uint8_t attempt = ARQ_RETRIES - arq_retries_left + 1;
  arq_retries_left--;
  jitter_armed = false;     // cancel any pending jitter TX — ARQ now owns this frame
  arq_timer = millis();
  tx_seq++;
  if (arq_pending) { arq_seq = tx_seq; }
  // Report AFTER arq_seq is updated: Pi's RETRY:seq and the subsequent ACK:seq
  // will match, making the UI correlation unambiguous.
  Serial.print(F("RETRY:")); print_hex_word(arq_seq);
  Serial.print(':'); Serial.println(attempt);
  tx_build(arq_payload, arq_payload_len, arq_flags_saved, tx_seq);
}

// ─────────────────────────────────────────────────────────────────────────────
//  LBT — non-blocking: reads lbt_edges_last set by ISR each bit period
//  No busy-wait; worst case 1 bit-period stale (20 ms at 50 baud) — acceptable.
// ─────────────────────────────────────────────────────────────────────────────
static bool lbt_busy(uint8_t flags) {
#ifdef LOOPBACK_TEST
  return false;
#endif
  if (((flags & F_PRI_MASK) >> F_PRI_SHIFT) == PRI_FLASH) return false;
  if (lbt_edges_last > edge_threshold) {
    Serial.println(F("LBT:BUSY"));
    return true;
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  TX initiate — enforces EMCON, jitter, LBT, sets up ARQ
// ─────────────────────────────────────────────────────────────────────────────
static void tx_initiate(const uint8_t* payload, uint8_t len, uint8_t flags) {
  if (emcon)        { Serial.println(F("DBG:EMCON — TX suppressed")); return; }
  if (tx_active)    { Serial.println(F("DBG:TX busy")); return; }
  if (jitter_armed) { Serial.println(F("DBG:TX busy (jitter pending)")); return; }

  // Always stash payload in arq_payload (used by jitter_pump even when no ARQ)
  memcpy(arq_payload, payload, len);
  arq_payload_len = len;
  arq_flags_saved = flags;

  // ARQ bookkeeping is set AFTER LBT and jitter checks pass — not here.
  // Setting arq_pending before lbt_busy() would leave arq_pending=true with
  // arq_timer=0 on LBT rejection. arq_pump would then fire after 5 s of uptime
  // and retransmit the LBT-dropped payload unsolicited. Same logic: jitter_armed
  // must be set only once we know the frame will eventually go out.

  if (jitter_en) {
    // Stash ARQ intent in flags; arq_pending is armed in jitter_pump at TX time.
    if (flags & F_ACK_REQ) {
      arq_retries_left = ARQ_RETRIES;
      // arq_pending set in jitter_pump, not here
    }
    jitter_ms    = (((uint16_t)lfsr_byte() << 1) | (lfsr_byte() & 1)) % 501;
    jitter_timer = millis();
    jitter_armed = true;
    return;
  }

  if (lbt_busy(flags)) return;   // LBT clear — safe to commit ARQ and TX
  tx_seq++;
  if (flags & F_ACK_REQ) {
    arq_retries_left = ARQ_RETRIES;
    arq_pending      = true;
    arq_seq          = tx_seq;
    arq_timer        = millis();
  }
  tx_build(payload, len, flags, tx_seq);
}

// Jitter pump: deferred TX after random delay
static void jitter_pump() {
  if (!jitter_armed || tx_active) return;
  if (millis() - jitter_timer < jitter_ms) return;

  if (lbt_busy(arq_flags_saved)) {
    // Channel busy — back off with a fresh short jitter window rather than
    // silently losing the frame.  Keep jitter_armed=true; reschedule.
    jitter_ms    = 50 + (lfsr_byte() & 0x3F);  // 50–113 ms backoff
    jitter_timer = millis();
    return;
  }

  jitter_armed = false;
  tx_seq++;
  // Arm ARQ here (not in tx_initiate) — committing only after LBT passes.
  // arq_retries_left was pre-loaded in tx_initiate; arq_pending was NOT set
  // to prevent arq_pump firing on a stale arq_timer if LBT dropped this frame.
  if (arq_flags_saved & F_ACK_REQ) {
    arq_pending = true;
    arq_seq     = tx_seq;
    arq_timer   = millis();
  }
  tx_build(arq_payload, arq_payload_len, arq_flags_saved, tx_seq);
}

// ─────────────────────────────────────────────────────────────────────────────
//  CW beacon state machine
// ─────────────────────────────────────────────────────────────────────────────
static bool cw_lookup(char c) {
  uint8_t idx = 0xFF;
  if (c >= 'A' && c <= 'Z') idx = c - 'A';
  else if (c >= '0' && c <= '9') idx = 26 + (c - '0');
  if (idx == 0xFF) return false;
  const char* pgm = (const char*)pgm_read_ptr(&CW_TABLE[idx]);
  uint8_t i = 0;
  char ch;
  while ((ch = pgm_read_byte(&pgm[i])) && i < 7) cw_pattern[i++] = ch;
  cw_pattern[i] = '\0';
  return true;
}

static void cw_pump() {
  if (!beacon_en || tx_active || arq_pending) return;
  uint32_t now = millis();

  if (cw_sm == CW_IDLE) {
    char mc = cw_msg[cw_char_idx];
    if (!mc) {
      // End of message — long inter-message pause then restart
      cw_sm=CW_TONE_OFF; cw_duration=CW_DIT_MS*14;
      cw_char_idx=0; cw_elem_idx=0; tone_off(); cw_timer=now; return;
    }
    if (mc == ' ') {
      cw_sm=CW_TONE_OFF; cw_duration=CW_DIT_MS*4;
      cw_char_idx++; cw_elem_idx=0; tone_off(); cw_timer=now; return;
    }
    if (cw_elem_idx == 0 && !cw_lookup(mc)) { cw_char_idx++; return; }
    char elem = cw_pattern[cw_elem_idx];
    if (!elem) {
      cw_sm=CW_TONE_OFF; cw_duration=CW_DIT_MS*2;
      cw_char_idx++; cw_elem_idx=0; tone_off(); cw_timer=now; return;
    }
    tone_mark();
    cw_sm=CW_TONE_ON; cw_duration=(elem=='-'?CW_DIT_MS*3:CW_DIT_MS);
    cw_timer=now; cw_elem_idx++;
  }
  else if (now - cw_timer >= cw_duration) {
    if (cw_sm == CW_TONE_ON) {
      tone_off(); cw_sm=CW_TONE_OFF; cw_duration=CW_DIT_MS; cw_timer=now;
    } else {
      cw_sm = CW_IDLE;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Manual Morse key
// ─────────────────────────────────────────────────────────────────────────────
static void morse_set(bool down) {
  if (down == morse_key_down) return;
  morse_key_down = down;
  down ? tone_mark() : tone_off();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Received-packet handler (runs in loop() context, not ISR)
// ─────────────────────────────────────────────────────────────────────────────
static void handle_rx_packet() {
  uint8_t  flags = rx_snap_flags;
  uint16_t seq   = rx_snap_seq;
  uint8_t  len   = rx_snap_len;

  if (rx_snap_netid != net_id) {
    Serial.print(F("DBG:foreign NETID 0x"));
    print_hex_byte(rx_snap_netid); Serial.println(); return;
  }

  // ACK received
  if (flags & F_IS_ACK) {
    if (len >= 2) {
      uint16_t acked = ((uint16_t)rx_snap_buf[0] << 8) | rx_snap_buf[1];
      Serial.print(F("ACK:")); print_hex_word(acked); Serial.println();
      if (arq_pending && acked == arq_seq) arq_pending = false;
    }
    return;
  }

  // Send ACK if requested
  if ((flags & F_ACK_REQ) && !tx_active) tx_send_ack(seq);

  // Strip padding
  uint8_t* payload    = rx_snap_buf;
  uint8_t  payload_len = len;
  if (flags & F_PADDED) {
    if (len < 2) return;
    uint8_t tl = rx_snap_buf[0];
    if (tl > len - 1) return;
    payload     = rx_snap_buf + 1;
    payload_len = tl;
  }

  // Emit to Pi
  Serial.print(F("RX:"));
  print_hex_byte(flags); Serial.print(':');
  print_hex_word(seq);   Serial.print(':');
  for (uint8_t i = 0; i < payload_len; i++) print_hex_byte(payload[i]);
  Serial.println();

  // RSSI estimate: lbt_edges_last counts edge transitions per bit-period.
  // A clear signal at 1000-2200 Hz produces ~25-88 edges per 20ms period.
  // Scale to 0-100%: 0 edges = no signal, 80+ edges = maximum.
  {
    uint8_t rssi = (uint8_t)min(100, (uint16_t)lbt_edges_last * 100 / 80);
    Serial.print(F("RSSI:")); Serial.println(rssi);
  }

  uint8_t pri = (flags & F_PRI_MASK) >> F_PRI_SHIFT;
  if (pri > PRI_ROUTINE) {
    Serial.print(F("DBG:PRI="));
    Serial.println((const __FlashStringHelper*)pgm_read_ptr(&PRI_STRS[pri]));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Dummy traffic pump
//  Respects EMCON. Goes through tx_initiate() so jitter/LBT apply.
// ─────────────────────────────────────────────────────────────────────────────
static void dummy_pump() {
  // Early-out includes emcon: if EMCON is active we must NOT reset the timer —
  // doing so would silently extend the inter-dummy gap by DUMMY_INTERVAL for
  // every blocked attempt, making the traffic pattern analysis protection useless
  // after a long EMCON window.
  if (!dummy_en || tx_active || arq_pending || beacon_en || emcon) return;
  if (millis() - dummy_timer < DUMMY_INTERVAL) return;
  dummy_timer = millis();

  uint8_t dp[16];
  for (uint8_t i = 0; i < 16; i++) dp[i] = lfsr_byte();
  // IS_DUMMY flag lets the Pi discard silently without decrypting
  tx_initiate(dp, 16, F_IS_DUMMY | F_PADDED | (PRI_ROUTINE << F_PRI_SHIFT));
  Serial.println(F("DBG:dummy TX"));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Serial command parser
// ─────────────────────────────────────────────────────────────────────────────
static char     cmd_buf[300];
static uint16_t cmd_pos = 0;

static void parse_cmd(const char* cmd) {

  if (!strcmp(cmd, "PING")) {
    Serial.println(F("PONG"));

  } else if (!strncmp(cmd, "TX:", 3)) {
    // Protocol: TX:<flags_hex2>:<payload_hex>
    // flags and payload are separated by ':'; flags = 00 means no options.
    const char* colon = strchr(cmd + 3, ':');
    if (!colon) { Serial.println(F("DBG:TX:missing flags")); return; }
    uint8_t  tx_flags = (unhex(cmd[3]) << 4) | unhex(cmd[4]);
    const char* h    = colon + 1;
    uint16_t    hlen = strlen(h);
    if (hlen & 1) { Serial.println(F("DBG:TX:odd hex")); return; }
    uint8_t plen = hlen >> 1;
    // PADDED_LEN-1: padded frame reserves 1 byte for true_len prefix;
    // allowing plen==PADDED_LEN would write 129 bytes into a 128-byte LEN field.
    if (plen >= PADDED_LEN) { Serial.println(F("DBG:TX:too long")); return; }
    static uint8_t payload[PADDED_LEN - 1];  // static: off stack (AVR has 2.5KB SRAM)
    for (uint8_t i = 0; i < plen; i++)
      payload[i] = (unhex(h[i*2]) << 4) | unhex(h[i*2+1]);
    tx_initiate(payload, plen, tx_flags);
    txopt = 0;   // clear any lingering TXOPT for safety

  } else if (!strncmp(cmd, "TXOPT:", 6)) {
    txopt = (unhex(cmd[6]) << 4) | unhex(cmd[7]);

  } else if (!strcmp(cmd, "KEY:1")) { morse_set(true);
  } else if (!strcmp(cmd, "KEY:0")) { morse_set(false);

  } else if (!strncmp(cmd, "BAUD:", 5)) {
    if (pkt_state != PS_IDLE)
      Serial.println(F("DBG:BAUD change mid-packet — current frame will corrupt"));
    if (atoi(cmd+5) == 100) {
      ticks_per_bit=10; edge_threshold=15; bit_period_ms=10;
      Serial.println(F("DBG:BAUD=100"));
    } else {
      ticks_per_bit=20; edge_threshold=30; bit_period_ms=20;
      Serial.println(F("DBG:BAUD=50"));
    }

  } else if (!strncmp(cmd, "NETID:", 6)) {
    net_id = (unhex(cmd[6]) << 4) | unhex(cmd[7]);
    Serial.print(F("DBG:NETID=0x")); print_hex_byte(net_id); Serial.println();

  } else if (!strcmp(cmd, "EMCON:1")) {
    emcon=true; tone_off(); Serial.println(F("EMCON:ON"));
  } else if (!strcmp(cmd, "EMCON:0")) {
    emcon=false;
    // Reset dummy_timer so we wait a full DUMMY_INTERVAL before the next
    // dummy transmission.  Without this, if EMCON was active for longer than
    // DUMMY_INTERVAL, dummy_pump would fire a dummy on the very first loop
    // tick after EMCON ends — transmitting the instant silence breaks is
    // tactically conspicuous.
    dummy_timer = millis();
    Serial.println(F("EMCON:OFF"));

  } else if (!strcmp(cmd, "BEACON:1")) {
    beacon_en=true; cw_sm=CW_IDLE; cw_char_idx=0; cw_elem_idx=0;
    Serial.println(F("BEACON:ON"));
  } else if (!strcmp(cmd, "BEACON:0")) {
    beacon_en=false; tone_off();
    cw_sm=CW_IDLE; cw_char_idx=0; cw_elem_idx=0;  // reset SM — clean restart on BEACON:1
    Serial.println(F("BEACON:OFF"));

  } else if (!strcmp(cmd, "DUMMY:1")) {
    dummy_en=true; dummy_timer=millis(); Serial.println(F("DBG:dummy ON"));
  } else if (!strcmp(cmd, "DUMMY:0")) {
    dummy_en=false; Serial.println(F("DBG:dummy OFF"));

  } else if (!strcmp(cmd, "JITTER:1")) {
    jitter_en=true; Serial.println(F("DBG:jitter ON"));
  } else if (!strcmp(cmd, "JITTER:0")) {
    jitter_en=false; Serial.println(F("DBG:jitter OFF"));

  } else if (!strcmp(cmd, "ZEROIZE")) {
    // Emergency zeroize: wipe all operational state, halt TX immediately.
    // Keys live on the Pi only — this node stores nothing sensitive.
    // Resets everything that could reveal operational patterns.
    tone_off();
    tx_active        = false;
    arq_pending      = false;
    jitter_armed     = false;
    emcon            = false;
    beacon_en        = false;
    dummy_en         = false;
    jitter_en        = false;
    net_id           = DEFAULT_NETID;
    tx_seq           = 0;
    arq_seq          = 0;
    arq_retries_left = 0;
    lfsr_state       = 0xDEAD;          // break fill-pattern continuity
    cw_sm            = CW_IDLE;
    cw_char_idx      = 0; cw_elem_idx = 0;
    memset(arq_payload, 0, sizeof(arq_payload));
    digitalWrite(RX_LED, HIGH);
    Serial.println(F("ZEROIZED"));

  } else if (!strcmp(cmd, "STATUS")) {
    Serial.print(F("STATUS:emcon="));   Serial.print(emcon?1:0);
    Serial.print(F(";beacon="));        Serial.print(beacon_en?1:0);
    Serial.print(F(";dummy="));         Serial.print(dummy_en?1:0);
    Serial.print(F(";jitter="));        Serial.print(jitter_en?1:0);
    Serial.print(F(";arq="));           Serial.print(arq_pending?1:0);
    Serial.print(F(";netid=0x"));       print_hex_byte(net_id);
    Serial.print(F(";txseq="));         Serial.print(tx_seq);
    Serial.print(F(";baud="));          Serial.println(bit_period_ms==10?100:50);

  } else {
    Serial.print(F("DBG:unknown: ")); Serial.println(cmd);
  }
}

// ── Debug byte ring (conditional) ─────────────────────────────────────────────
#ifdef DEBUG_BYTES
volatile uint8_t dbg_buf[32];
volatile uint8_t dbg_wr = 0, dbg_rd = 0;
#endif

// ─────────────────────────────────────────────────────────────────────────────
//  setup()
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(9600);
  while (!Serial) delay(10);

  pinMode(RX_PIN, INPUT);
  pinMode(TX_PIN, OUTPUT);
  pinMode(RX_LED, OUTPUT);
  digitalWrite(RX_LED, HIGH);

  // Seed LFSR from two separate ADC reads for better entropy
  lfsr_state ^= (uint16_t)analogRead(A3) | ((uint16_t)analogRead(A2) << 8);

  snprintf(cw_msg, CW_MSG_LEN, "SOS DE %s", CW_CALLSIGN);

  // Timer3 CTC 1 kHz: f = F_CPU / (prescaler*(OCR3A+1))
  // 16e6 / (8 * 2000) = 1000 Hz
  TCCR3A = 0;
  TCCR3B = (1<<WGM32)|(1<<CS31);  // CTC, prescaler=8
  OCR3A  = 1999;
  TIMSK3 = (1<<OCIE3A);
  sei();

  Serial.println(F("READY"));
}

// ─────────────────────────────────────────────────────────────────────────────
//  loop()
// ─────────────────────────────────────────────────────────────────────────────
void loop() {

  // ── Atomically snapshot received packet before releasing pkt_ready ──────────
  // cli/sei ensure the copy is atomic: the ISR cannot update pkt_buf/pkt_* or
  // set pkt_ready=false while we're copying.  We set pkt_ready=false inside the
  // cli block so the ISR can accept the next packet immediately afterwards.
  if (pkt_ready && !rx_snap_ready) {
    cli();
    rx_snap_netid = pkt_netid;
    rx_snap_flags = pkt_flags;
    rx_snap_seq   = pkt_seq;
    rx_snap_len   = pkt_len;
    memcpy(rx_snap_buf, (const void*)pkt_buf, rx_snap_len);
    pkt_ready     = false;   // ISR may now accept next packet
    rx_snap_ready = true;
    sei();
  }

  if (rx_snap_ready) {
    rx_snap_ready = false;
    handle_rx_packet();
  }

  // ── Sub-systems ──────────────────────────────────────────────────────────────
  tx_pump();
  arq_pump();
  jitter_pump();
  dummy_pump();
  cw_pump();

  // ── Serial command input ──────────────────────────────────────────────────────
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (cmd_pos > 0) {
        cmd_buf[cmd_pos] = '\0';
        parse_cmd(cmd_buf);
        cmd_pos = 0;
      }
    } else if (cmd_pos < (uint16_t)(sizeof(cmd_buf) - 1)) {
      cmd_buf[cmd_pos++] = c;
    }
  }

#ifdef DEBUG_BYTES
  while (dbg_rd != dbg_wr) {
    uint8_t b = dbg_buf[dbg_rd]; dbg_rd = (dbg_rd+1)&31;
    Serial.print(F("DBG:byte=0x")); print_hex_byte(b);
    Serial.print(F(" sm=")); Serial.println((int)pkt_state);
  }
#endif
}
