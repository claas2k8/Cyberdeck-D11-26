# Cyberdeck Military Comms Suite

PMR446 encrypted radio messenger for Raspberry Pi.  
ChaCha20-Poly1305 encryption · RTTY modem · ATmega32U4 firmware · PyQt5 GUI.

```
┌─────────────────────────────────────────────────────────┐
│ 150347Z MAR 26                KEY:A1B2C3D4   [OK]  ALPHA│
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ALPHA>>BRAVO  130900Z MAR 26  SEQ:0001 [ENC]          │
│  RADIO CHECK, HOW DO YOU READ?                          │
│                                                         │
│  BRAVO<<ALPHA  130901Z MAR 26  SEQ:0002 [ENC]          │
│  LOUD AND CLEAR, 5 BY 5.                                │
│                                                         │
├─────────────────────────────────────────────────────────┤
│ LOUD AND CLEAR...                                    24 │
├ BRAVO │ TYPE MESSAGE — ENTER TO TRANSMIT  │ACK│PAD│ TX ┤
└─────────────────────────────────────────────────────────┘
```

---

## Hardware

| Part | Detail |
|---|---|
| Modem | SparkFun Pro Micro (ATmega32U4, 5V/16 MHz) |
| Computer | Raspberry Pi 3B (or any Pi with USB + 40-pin GPIO) |
| GPS | GY-NEO6MV2 (u-blox NEO-6M) → Pi GPIO15 / ttyAMA0 |
| Radio | Any PMR446 handheld |
| TX audio | Pro Micro Pin 6 (PD7/OC4A) → Radio MIC-IN |
| RX audio | Pro Micro Pin 3 (PD0) ← Radio SPKR+ |

RTTY: MARK 1000 Hz · SPACE 2000 Hz · 50/100 baud selectable  
Crypto: ChaCha20-Poly1305 · PBKDF2-SHA256 · 200 000 rounds

---

## Install

### Option 1 — One-liner (Raspberry Pi, no git required)

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/cyberdeck/main/install.sh)
```

Installs system packages via apt, creates the `cyberdeck` terminal command,
adds a desktop icon, configures UART for GPS.

---

### Option 2 — pip from GitHub

```bash
# On Raspberry Pi: install PyQt5 via apt first (pip wheel may fail on ARM)
sudo apt install python3-pyqt5 python3-serial

# Then install the Python package from GitHub
pip install "git+https://github.com/YOUR_USERNAME/cyberdeck.git#egg=cyberdeck-milcomms[pi]" \
    --break-system-packages
```

This creates the `cyberdeck` command in your PATH.  
Does **not** configure UART, dialout group, or desktop icon.  
Run `install.sh` afterwards for full Pi setup.

---

### Option 3 — Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/cyberdeck.git
bash cyberdeck/install.sh
```

---

### Option 4 — Editable / developer install

```bash
git clone https://github.com/YOUR_USERNAME/cyberdeck.git
cd cyberdeck

sudo apt install python3-pyqt5 python3-serial python3-pip
pip install -e ".[pi]" --break-system-packages

# Run directly
cyberdeck
# or
python -m cyberdeck
```

---

## Usage

```bash
cyberdeck                        # launch (auto-detects screen size)
cyberdeck --update               # update in-place
cyberdeck --reset                # wipe ~/.cyberdeck/settings.json + key
cyberdeck --display 35inch       # force 3.5" display layout
cyberdeck --display 5inch        # force 5" display layout
cyberdeck --display full         # force desktop layout
cyberdeck --port /dev/ttyACM1   # override modem port
```

**Display profiles** auto-detected from screen width:

| Profile | Screen | Resolution |
|---|---|---|
| `full` | Desktop / HDMI | ≥ 900 px wide |
| `5inch` | Waveshare 5" HDMI | 800 × 480 |
| `35inch` | Waveshare 3.5" SPI | 480 × 320 |

---

## Keybinds

| Key | Action |
|---|---|
| `Enter` | Send message |
| `Space` (when input not focused) | Morse key down/up |
| `Ctrl+,` | Settings |
| `Ctrl+Shift+Z` | Zeroize (emergency key wipe) |
| `Ctrl+E` | Toggle EMCON (receive-only mode) |
| `Ctrl+B` | Toggle CW distress beacon |
| `Ctrl+P` | Ping modem |
| `Ctrl+L` | Clear message log |
| `Ctrl+1` | Quick TX: RADIO CHECK |
| `Ctrl+2` | Quick TX: ROGER. OUT. |
| `Ctrl+3` | Quick TX: WILCO. OUT. |
| `Ctrl+4` | Quick TX: WAIT. OUT. |

---

## Update

```bash
# From anywhere after install:
cyberdeck --update

# Or re-run install.sh from the project directory:
bash install.sh
```

---

## Uninstall

```bash
rm -rf ~/.local/share/cyberdeck
rm -f  ~/.local/bin/cyberdeck
rm -f  ~/.local/share/applications/cyberdeck.desktop
rm -f  ~/Desktop/Cyberdeck.desktop

# Remove user data (chat log, settings, key salt):
rm -rf ~/.cyberdeck
```

---

## Arduino firmware

Open `arduino/cyberdeck_v7.ino` in Arduino IDE.

- Board: **SparkFun Pro Micro**
- Processor: **ATmega32U4 (5V, 16 MHz)**
- Before flashing for real radio: comment out `#define LOOPBACK_TEST` at the top of the file

---

## Publish to PyPI (optional)

```bash
pip install build twine --break-system-packages
python -m build
twine upload dist/*
# Then anyone can: pip install cyberdeck-milcomms
```

After publishing to PyPI, install becomes:

```bash
pip install cyberdeck-milcomms --break-system-packages
```

---

## Security notes

- Passphrase is **never written to disk**. Only a fixed application salt is stored.
- Both radio nodes must use the **same passphrase** to communicate.
- Verify the COMSEC fingerprint (first 8 hex chars of SHA-256 of derived key)
  shown in the header bar matches on both sides before transmitting.
- Use **ZEROIZE** (`Ctrl+Shift+Z`) to immediately wipe the key from memory
  and reset the Arduino to default state.
- PMR446 is a public band. Security relies entirely on the encryption layer.
  Encrypted transmission may be prohibited in some jurisdictions — check local regulations.

---

## License

MIT — see [LICENSE](LICENSE)
