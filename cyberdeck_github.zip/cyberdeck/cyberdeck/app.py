#!/usr/bin/env python3
"""
app.py — Cyberdeck Military Comms Suite v9
Stripped to core: incoming/outgoing chat, live typing preview, spacebar Morse.

Usage:
  python3 app.py [--port /dev/ttyACM0] [--reset] [--display full|5inch|35inch]

Keybinds:
  Enter          — send message
  Space (no focus) — Morse key down/up
  Ctrl+,         — settings
  Ctrl+Shift+Z   — zeroize
  Ctrl+E         — toggle EMCON
  Ctrl+B         — toggle beacon
  Ctrl+P         — ping
  Ctrl+L         — clear log
  Ctrl+1..4      — quick templates (radio check, roger, wilco, wait out)
"""

import sys, os, json, sqlite3, argparse, logging, time, threading, hashlib
from datetime import datetime, timezone

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QDialog, QFormLayout,
    QDialogButtonBox, QCheckBox, QAction, QSpinBox, QComboBox, QFrame,
)
from PyQt5.QtCore  import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui   import QFont, QTextCursor, QKeySequence

sys.path.insert(0, os.path.dirname(__file__))  # kept for direct python app.py invocation
try:
    from .serial_modem   import (SerialModem, make_txopt,
                                 EVT_READY, EVT_RX, EVT_RSSI, EVT_TXSTART,
                                 EVT_TXDONE, EVT_LBT_BUSY, EVT_DBG,
                                 EVT_CONNECT, EVT_DISCONNECT, EVT_PONG,
                                 EVT_ACK, EVT_RETRY, EVT_FAIL, EVT_STATUS,
                                 EVT_EMCON, EVT_BEACON, EVT_ZEROIZED)
    from .crypto_manager import CryptoManager
    from .gps_reader     import GpsReader
except ImportError:
    # Fallback for direct invocation: python3 cyberdeck/app.py
    from serial_modem   import (SerialModem, make_txopt,
                                 EVT_READY, EVT_RX, EVT_RSSI, EVT_TXSTART,
                                 EVT_TXDONE, EVT_LBT_BUSY, EVT_DBG,
                                 EVT_CONNECT, EVT_DISCONNECT, EVT_PONG,
                                 EVT_ACK, EVT_RETRY, EVT_FAIL, EVT_STATUS,
                                 EVT_EMCON, EVT_BEACON, EVT_ZEROIZED)
    from crypto_manager import CryptoManager
    from gps_reader     import GpsReader

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("app")

APP_DIR            = os.path.expanduser("~/.cyberdeck")
SETTINGS_FILE      = os.path.join(APP_DIR, "settings.json")
CHAT_DB            = os.path.join(APP_DIR, "chat.db")
KEY_FILE           = os.path.join(APP_DIR, "key.enc")
MAX_PAYLOAD        = 128
MAX_PAYLOAD_PADDED = MAX_PAYLOAD - 1
ARQ_RETRIES        = 3

DEFAULTS = {
    "port":      "/dev/ttyACM0",
    "callsign":  "ALPHA",
    "gps_port":  "/dev/ttyAMA0",
    "font_size": 11,
    "show_dbg":  False,
    "net_id":    "CD",
    "baud":      50,
    "dst":       "BRAVO",
    "ack":       True,
    "pad":       False,
}

_MONTHS = ["JAN","FEB","MAR","APR","MAY","JUN",
           "JUL","AUG","SEP","OCT","NOV","DEC"]

# Quick-key templates (Ctrl+1 … Ctrl+4)
QUICK = [
    "RADIO CHECK, HOW DO YOU READ?",
    "ROGER. OUT.",
    "WILCO. OUT.",
    "WAIT. OUT.",
]

# ── Phosphor palette ───────────────────────────────────────────────────────────
C = {
    "bg":       "#020902",
    "bg2":      "#040c04",
    "bg3":      "#071207",
    "border":   "#0d2d0d",
    "text":     "#1ab81a",
    "dim":      "#0a5a0a",
    "green":    "#2eff2e",
    "amber":    "#ffaa00",
    "red":      "#ff2200",
    "blue":     "#00ccff",
    "white":    "#aaffaa",
    "self_bg":  "#020e02",
    "other_bg": "#040c04",
    "flash":    "#ff0000",
    "immediate":"#ff6600",
    "priority": "#ffcc00",
    "routine":  "#1ab81a",
    "hdr_bg":   "#010701",
    "prev_bg":  "#010701",   # preview strip background
}

PRI_COLOURS = {0: C["routine"], 1: C["priority"],
               2: C["immediate"], 3: C["flash"]}

# ── Per-profile constants (min_w, min_h, font_body, hdr_h, compose_h, preview_h)
_PROFILES = {
    "full":   (900,  560, 11, 26, 30, 18),
    "5inch":  (800,  480,  9, 22, 26, 15),
    "35inch": (480,  320,  8, 18, 24, 13),
}

def _style(fs: int) -> str:
    p = max(2, fs // 3)
    return f"""
QWidget        {{ background:{C['bg']}; color:{C['text']}; font-family:Monospace; font-size:{fs}pt; }}
QTextEdit      {{ background:{C['bg2']}; border:none; color:{C['text']};
                  selection-background-color:#0a3a0a; }}
QLineEdit      {{ background:{C['bg3']}; border:1px solid {C['border']};
                  color:{C['text']}; padding:{p}px {p*2}px; }}
QLineEdit:focus {{ border-color:{C['green']}; }}
QPushButton    {{ background:{C['bg3']}; border:1px solid {C['border']};
                  color:{C['text']}; padding:{p}px {p*2}px; }}
QPushButton:hover   {{ border-color:{C['green']}; color:{C['green']}; }}
QPushButton:pressed {{ background:#0a1a0a; }}
QPushButton:disabled {{ color:{C['dim']}; border-color:{C['dim']}; }}
QPushButton#tx_btn {{ background:#071f07; color:{C['green']};
                      font-weight:bold; border:1px solid {C['green']}; }}
QPushButton#tx_btn:hover {{ background:#0d2e0d; }}
QPushButton#tx_btn:disabled {{ background:{C['bg3']}; color:{C['dim']};
                                border-color:{C['dim']}; }}
QLabel         {{ color:{C['text']}; border:none; background:transparent; }}
QComboBox      {{ background:{C['bg3']}; border:1px solid {C['border']};
                  color:{C['text']}; padding:{p}px; }}
QComboBox QAbstractItemView {{ background:{C['bg3']}; color:{C['text']};
                                selection-background-color:#0a3a0a; }}
QComboBox::drop-down {{ border:none; width:10px; }}
QCheckBox      {{ color:{C['dim']}; spacing:4px; font-size:{max(6,fs-1)}pt; }}
QCheckBox::indicator {{ width:9px; height:9px; border:1px solid {C['border']};
                        background:{C['bg3']}; }}
QCheckBox::indicator:checked {{ background:{C['green']}; border-color:{C['green']}; }}
QStatusBar     {{ background:{C['bg2']}; border-top:1px solid {C['border']};
                  color:{C['dim']}; font-size:{max(6,fs-2)}pt; }}
QMenuBar       {{ background:{C['bg2']}; border-bottom:1px solid {C['border']};
                  color:{C['text']}; }}
QMenuBar::item {{ padding:3px 8px; background:transparent; }}
QMenuBar::item:selected {{ background:{C['bg3']}; color:{C['green']}; }}
QMenu          {{ background:{C['bg2']}; border:1px solid {C['border']}; color:{C['text']}; }}
QMenu::item:selected {{ background:#0a3a0a; color:{C['green']}; }}
QScrollBar:vertical {{ background:{C['bg2']}; width:4px; border:none; }}
QScrollBar::handle:vertical {{ background:{C['border']}; border-radius:2px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0; }}
QSpinBox       {{ background:{C['bg3']}; border:1px solid {C['border']};
                  color:{C['text']}; padding:{p}px; }}
QDialog        {{ background:{C['bg']}; }}
"""


def _he(t: str) -> str:
    return t.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

def _dtg_now() -> str:
    n = datetime.now(timezone.utc)
    return f"{n.day:02d}{n.hour:02d}{n.minute:02d}Z {_MONTHS[n.month-1]} {n.year%100:02d}"

def _dtg_ts(ts: float) -> str:
    n = datetime.fromtimestamp(ts, tz=timezone.utc)
    return f"{n.day:02d}{n.hour:02d}{n.minute:02d}Z {_MONTHS[n.month-1]} {n.year%100:02d}"

def _zulu() -> str:
    n = datetime.now(timezone.utc)
    return f"{n.hour:02d}{n.minute:02d}{n.second:02d}Z"

def _key_fp(key_bytes) -> str:
    if not key_bytes: return "--------"
    return hashlib.sha256(key_bytes).hexdigest()[:8].upper()

def _detect_profile(override: str | None) -> str:
    if override and override in _PROFILES:
        return override
    try:
        s = QApplication.primaryScreen()
        if s:
            w = s.size().width()
            if w < 600: return "35inch"
            if w < 900: return "5inch"
    except Exception:
        pass
    return "full"


# ── Signals ────────────────────────────────────────────────────────────────────
class Signals(QObject):
    rx_msg       = pyqtSignal(dict)
    rx_err       = pyqtSignal(str)
    rssi         = pyqtSignal(int)
    tx_start     = pyqtSignal(int)
    tx_done      = pyqtSignal()
    lbt_busy     = pyqtSignal()
    dbg          = pyqtSignal(str)
    connected    = pyqtSignal(str)
    disconnected = pyqtSignal()
    ping_rtt     = pyqtSignal(float)
    ack          = pyqtSignal(int)
    retry        = pyqtSignal(dict)
    fail         = pyqtSignal(int)
    status       = pyqtSignal(dict)
    emcon_chg    = pyqtSignal(bool)
    beacon_chg   = pyqtSignal(bool)
    zeroized     = pyqtSignal()


# ── Database ───────────────────────────────────────────────────────────────────
class ChatDB:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._db   = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        self._init()

    def _init(self):
        with self._lock:
            self._db.execute("""CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER, src TEXT, dst TEXT, body TEXT,
                raw_hex TEXT, inbound INTEGER,
                encrypted INTEGER DEFAULT 0,
                priority INTEGER DEFAULT 0,
                seq INTEGER DEFAULT 0
            )""")
            for col in ("encrypted INTEGER DEFAULT 0",
                        "priority INTEGER DEFAULT 0",
                        "seq INTEGER DEFAULT 0"):
                try: self._db.execute(f"ALTER TABLE messages ADD COLUMN {col}")
                except sqlite3.OperationalError: pass
            self._db.commit()

    def save(self, src, dst, body, raw: bytes, inbound: bool,
             encrypted: bool, priority: int = 0, seq: int = 0):
        with self._lock:
            self._db.execute(
                "INSERT INTO messages(ts,src,dst,body,raw_hex,inbound,"
                "encrypted,priority,seq) VALUES(?,?,?,?,?,?,?,?,?)",
                (int(time.time()), src, dst, body,
                 raw.hex() if raw else "", int(inbound),
                 int(encrypted), priority, seq))
            self._db.commit()

    def load_recent(self, n: int = 80) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT ts,src,dst,body,inbound,encrypted,priority,seq"
                " FROM messages ORDER BY id DESC LIMIT ?", (n,)
            ).fetchall()
        return [{"ts":r[0],"src":r[1],"dst":r[2],"body":r[3],
                 "inbound":bool(r[4]),"encrypted":bool(r[5]),
                 "priority":r[6],"seq":r[7]}
                for r in reversed(rows)]


# ── Dialogs ────────────────────────────────────────────────────────────────────
class PassphraseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("COMSEC KEY LOAD")
        self.setMinimumWidth(300)
        lo = QVBoxLayout(self)
        info = QLabel("PASSPHRASE  (ChaCha20-Poly1305 / PBKDF2)\nBLANK = PLAINTEXT MODE")
        info.setAlignment(Qt.AlignCenter)
        info.setStyleSheet(f"color:{C['dim']};")
        lo.addWidget(info)
        self._pw = QLineEdit()
        self._pw.setEchoMode(QLineEdit.Password)
        self._pw.setAlignment(Qt.AlignCenter)
        self._pw.returnPressed.connect(self.accept)
        lo.addWidget(self._pw)
        bb = QDialogButtonBox(QDialogButtonBox.Ok)
        bb.button(QDialogButtonBox.Ok).setText("LOAD")
        bb.accepted.connect(self.accept)
        lo.addWidget(bb)

    def passphrase(self): return self._pw.text()


class SettingsDialog(QDialog):
    def __init__(self, s: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CONFIGURATION")
        self.setMinimumWidth(360)
        self._s = dict(s)
        lo   = QVBoxLayout(self)
        form = QFormLayout(); form.setSpacing(6)

        def lbl(t):
            l = QLabel(t); l.setStyleSheet(f"color:{C['dim']};"); return l

        self._port     = QLineEdit(self._s.get("port",     DEFAULTS["port"]))
        self._callsign = QLineEdit(self._s.get("callsign", DEFAULTS["callsign"]))
        self._callsign.setMaxLength(10)
        self._gps_port = QLineEdit(self._s.get("gps_port", DEFAULTS["gps_port"]))
        self._net_id   = QLineEdit(self._s.get("net_id",   DEFAULTS["net_id"]))
        self._net_id.setMaxLength(2)
        self._baud = QComboBox()
        self._baud.addItems(["50", "100"])
        self._baud.setCurrentText(str(self._s.get("baud", 50)))
        self._font = QSpinBox(); self._font.setRange(6, 18)
        self._font.setValue(self._s.get("font_size", 11))
        self._dbg = QCheckBox("SHOW ARDUINO DEBUG MESSAGES")
        self._dbg.setChecked(self._s.get("show_dbg", False))

        form.addRow(lbl("SERIAL PORT:"), self._port)
        form.addRow(lbl("CALLSIGN:"),    self._callsign)
        form.addRow(lbl("GPS PORT:"),    self._gps_port)
        form.addRow(lbl("NET ID HEX:"),  self._net_id)
        form.addRow(lbl("RTTY BAUD:"),   self._baud)
        form.addRow(lbl("FONT SIZE:"),   self._font)
        form.addRow(QLabel(""),          self._dbg)
        lo.addLayout(form)

        note = QLabel("COMSEC PASSPHRASE SET AT STARTUP — RESTART TO CHANGE")
        note.setStyleSheet(f"color:{C['dim']};"); note.setWordWrap(True)
        lo.addWidget(note)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("APPLY")
        bb.button(QDialogButtonBox.Cancel).setText("CANCEL")
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject)
        lo.addWidget(bb)

    def _ok(self):
        self._s.update({
            "port":      self._port.text().strip(),
            "callsign":  self._callsign.text().strip().upper(),
            "gps_port":  self._gps_port.text().strip(),
            "net_id":    self._net_id.text().strip().upper() or "CD",
            "baud":      int(self._baud.currentText()),
            "font_size": self._font.value(),
            "show_dbg":  self._dbg.isChecked(),
        })
        self.accept()

    def get_settings(self): return self._s


class ZeroizeDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("!! ZEROIZE !! CONFIRM")
        lo = QVBoxLayout(self)
        warn = QLabel(
            "!! WARNING !!\n\n"
            "WIPE COMSEC KEY FROM MEMORY\n"
            "RESET ARDUINO STATE\n\n"
            "IRREVERSIBLE — CONFIRM?")
        warn.setAlignment(Qt.AlignCenter)
        warn.setStyleSheet(f"color:{C['red']}; font-weight:bold; padding:12px;")
        lo.addWidget(warn)
        bb = QDialogButtonBox()
        ok  = bb.addButton("ZEROIZE NOW", QDialogButtonBox.AcceptRole)
        ok.setStyleSheet(
            f"background:#1a0000; color:{C['red']};"
            f" border:1px solid {C['red']}; font-weight:bold; padding:4px 12px;")
        bb.addButton("CANCEL", QDialogButtonBox.RejectRole)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lo.addWidget(bb)


# ── Main window ────────────────────────────────────────────────────────────────
class MainWindow(QMainWindow):
    def __init__(self, args):
        super().__init__()
        self._args      = args
        self._profile   = _detect_profile(getattr(args, "display", None))
        self._sigs      = Signals()
        self._ping_t    = 0.0
        self._tx_busy   = False
        self._last_rssi = -1
        self._emcon     = False
        self._beacon    = False
        self._seen_seqs: dict[int, None] = {}
        self._morse_down = False   # spacebar Morse state

        os.makedirs(APP_DIR, mode=0o700, exist_ok=True)
        self._settings = self._load_settings()
        if args.port:
            self._settings["port"] = args.port

        self._db     = ChatDB(CHAT_DB)
        self._crypto = CryptoManager()

        _, _, fs, *_ = _PROFILES[self._profile]
        self.setStyleSheet(_style(fs))

        pp_dlg = PassphraseDialog()
        pp_dlg.setStyleSheet(_style(fs))
        pp_dlg.exec_()
        pp = pp_dlg.passphrase()
        if pp: self._crypto.load_passphrase(pp)
        else:  self._crypto.set_passphrase("")

        self._modem = SerialModem(port=self._settings["port"])
        self._gps   = GpsReader(port=self._settings["gps_port"])
        sz = self._settings.get("font_size", fs)
        self._mono  = QFont("Monospace", sz)
        self._mono.setStyleHint(QFont.TypeWriter)

        self._build_ui()
        self._wire_signals()
        self._wire_modem()
        self._gps.start()
        self._start_timers()
        self._load_history()
        self.show()

    # ── settings ──────────────────────────────────────────────────────────────

    def _load_settings(self) -> dict:
        try:
            with open(SETTINGS_FILE) as f: s = json.load(f)
            for k, v in DEFAULTS.items(): s.setdefault(k, v)
            return s
        except (FileNotFoundError, json.JSONDecodeError):
            return dict(DEFAULTS)

    def _save_settings(self):
        # Persist last-used dst, ack, pad back to settings
        if hasattr(self, "_dst"):
            self._settings["dst"] = self._dst.text().strip().upper() or "BRAVO"
        if hasattr(self, "_ack_chk"):
            self._settings["ack"] = self._ack_chk.isChecked()
        if hasattr(self, "_pad_chk"):
            self._settings["pad"] = self._pad_chk.isChecked()
        with open(SETTINGS_FILE, "w") as f:
            json.dump(self._settings, f, indent=2)

    # ── UI ─────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        _, _, fs, hdr_h, compose_h, prev_h = _PROFILES[self._profile]
        cs  = self._settings["callsign"]
        net = self._settings["net_id"]
        enc = self._crypto.active
        fp  = _key_fp(getattr(self._crypto, "_key", None))

        self.setWindowTitle(f"CYBERDECK  {cs}  NET:0x{net}")
        mw, mh = _PROFILES[self._profile][:2]
        self.setMinimumSize(mw, mh)
        if self._profile != "full":
            self.resize(mw, mh)

        # ── Menu (all controls live here) ──────────────────────────────────────
        mb = self.menuBar()

        fm = mb.addMenu("FILE")
        fm.addAction(self._act("CONFIGURATION...", "Ctrl+,",   self._open_settings))
        fm.addSeparator()
        fm.addAction(self._act("QUIT",             "Ctrl+Q",   self.close))

        cm = mb.addMenu("COMMS")
        self._emcon_act  = self._act("EMCON OFF",   "Ctrl+E",   self._toggle_emcon)
        self._beacon_act = self._act("BEACON OFF",  "Ctrl+B",   self._toggle_beacon)
        cm.addAction(self._emcon_act)
        cm.addAction(self._beacon_act)
        cm.addSeparator()
        cm.addAction(self._act("TX JITTER ON",  None, lambda: self._modem.set_jitter(True)))
        cm.addAction(self._act("TX JITTER OFF", None, lambda: self._modem.set_jitter(False)))
        cm.addAction(self._act("DUMMY TX ON",   None, lambda: self._modem.set_dummy(True)))
        cm.addAction(self._act("DUMMY TX OFF",  None, lambda: self._modem.set_dummy(False)))
        cm.addSeparator()
        cm.addAction(self._act("[!!] ZEROIZE", "Ctrl+Shift+Z", self._do_zeroize))

        tm = mb.addMenu("TOOLS")
        tm.addAction(self._act("PING",           "Ctrl+P", self._do_ping))
        tm.addAction(self._act("CLEAR LOG",       "Ctrl+L", self._clear_log))
        tm.addAction(self._act("REQUEST STATUS",  None,
                                lambda: self._modem.request_status()))
        tm.addSeparator()
        # Quick templates via menu
        for i, t in enumerate(QUICK, 1):
            short = t[:30] + "..." if len(t) > 30 else t
            tm.addAction(self._act(f"Ctrl+{i}  {short}", f"Ctrl+{i}",
                                   lambda _, txt=t: self._insert_template(txt)))

        # ── Central layout ─────────────────────────────────────────────────────
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header bar
        hdr = QWidget()
        hdr.setFixedHeight(hdr_h)
        hdr.setStyleSheet(
            f"background:{C['hdr_bg']}; border-bottom:1px solid {C['border']};")
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(6, 0, 6, 0)
        hl.setSpacing(8)

        self._hdr_clock = QLabel("000000Z")
        self._hdr_clock.setFont(QFont("Monospace", fs + 1))
        self._hdr_clock.setStyleSheet(
            f"color:{C['green']}; font-weight:bold; border:none;")

        def _vd():
            f = QFrame(); f.setFrameShape(QFrame.VLine); f.setFixedWidth(1)
            f.setStyleSheet(f"background:{C['border']}; border:none; margin:3px 0;")
            return f

        enc_col = C["green"] if enc else C["amber"]
        self._hdr_comsec = QLabel(f"KEY:{fp}" if enc else "NO KEY")
        self._hdr_comsec.setStyleSheet(f"color:{enc_col}; border:none;")

        self._hdr_modem = QLabel("[--]")
        self._hdr_modem.setStyleSheet(f"color:{C['red']}; border:none;")

        self._hdr_id = QLabel(f"{cs}  NET:{net}")
        self._hdr_id.setStyleSheet(f"color:{C['dim']}; border:none;")

        hl.addWidget(self._hdr_clock)
        hl.addWidget(_vd())
        hl.addWidget(self._hdr_comsec)
        hl.addWidget(_vd())
        hl.addWidget(self._hdr_modem)
        hl.addStretch(1)
        hl.addWidget(self._hdr_id)
        root.addWidget(hdr)

        # Message log — takes all remaining height
        self._chat = QTextEdit()
        self._chat.setReadOnly(True)
        self._chat.setFont(self._mono)
        self._chat.setLineWrapMode(QTextEdit.WidgetWidth)
        self._chat.setStyleSheet(
            f"background:{C['bg2']}; border:none; color:{C['text']};")
        root.addWidget(self._chat, 1)

        # Typing preview strip
        prev = QWidget()
        prev.setFixedHeight(prev_h)
        prev.setStyleSheet(
            f"background:{C['prev_bg']}; border-top:1px solid {C['border']};")
        pl = QHBoxLayout(prev)
        pl.setContentsMargins(6, 1, 6, 1)
        self._preview = QLabel("")
        self._preview.setFont(QFont("Monospace", max(6, fs - 2)))
        self._preview.setStyleSheet(f"color:{C['dim']}; border:none;")
        self._preview.setTextFormat(Qt.PlainText)
        self._char_count = QLabel("0")
        self._char_count.setFont(QFont("Monospace", max(6, fs - 2)))
        self._char_count.setStyleSheet(f"color:{C['dim']}; border:none;")
        self._char_count.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self._char_count.setFixedWidth(30)
        pl.addWidget(self._preview, 1)
        pl.addWidget(self._char_count)
        root.addWidget(prev)

        # Compose bar
        compose = QWidget()
        compose.setFixedHeight(compose_h)
        compose.setStyleSheet(
            f"background:{C['bg3']}; border-top:1px solid {C['border']};")
        cl = QHBoxLayout(compose)
        cl.setContentsMargins(4, 2, 4, 2)
        cl.setSpacing(4)

        self._dst = QLineEdit(self._settings.get("dst", "BRAVO"))
        self._dst.setPlaceholderText("TO")
        self._dst.setFixedWidth(max(48, fs * 5))
        self._dst.setFixedHeight(compose_h - 4)

        self._msg = QLineEdit()
        self._msg.setPlaceholderText("TYPE MESSAGE — ENTER TO TRANSMIT")
        self._msg.setFont(self._mono)
        self._msg.setFixedHeight(compose_h - 4)
        self._msg.returnPressed.connect(self._send_message)
        self._msg.textChanged.connect(self._on_text_changed)

        self._ack_chk = QCheckBox("ACK")
        self._ack_chk.setChecked(self._settings.get("ack", True))
        self._ack_chk.setFixedHeight(compose_h - 4)

        self._pad_chk = QCheckBox("PAD")
        self._pad_chk.setChecked(self._settings.get("pad", False))
        self._pad_chk.setFixedHeight(compose_h - 4)

        self._tx_btn = QPushButton("TX")
        self._tx_btn.setObjectName("tx_btn")
        self._tx_btn.setFixedHeight(compose_h - 4)
        self._tx_btn.setFixedWidth(max(30, fs * 3))
        self._tx_btn.clicked.connect(self._send_message)

        cl.addWidget(self._dst)
        cl.addWidget(self._msg, 1)
        cl.addWidget(self._ack_chk)
        cl.addWidget(self._pad_chk)
        cl.addWidget(self._tx_btn)
        root.addWidget(compose)

        # Status bar — modem, RSSI, seq, RTT
        sb = self.statusBar()
        sb.setStyleSheet(
            f"QStatusBar {{ background:{C['bg2']}; border-top:1px solid {C['border']};"
            f" color:{C['dim']}; font-size:{max(6,fs-2)}pt; }}")
        self._sb_modem = QLabel("  MODEM: OFFLINE")
        self._sb_rssi  = QLabel("RSSI:---")
        self._sb_seq   = QLabel("SEQ:----")
        self._sb_rtt   = QLabel("RTT:---")
        sb.addWidget(self._sb_modem)
        sb.addPermanentWidget(self._sb_seq)
        sb.addPermanentWidget(self._sb_rssi)
        sb.addPermanentWidget(self._sb_rtt)

        # Boot banner
        self._log_sys(
            f"CYBERDECK v9  {cs}  NET:0x{net}  "
            f"COMSEC:{'ON' if enc else 'OFF'}  FP:{fp}  "
            f"DISPLAY:{self._profile.upper()}  "
            f"[SPACE=MORSE  Ctrl+1-4=QUICK TX]")

    def _act(self, label, shortcut, fn) -> QAction:
        a = QAction(label, self)
        if shortcut: a.setShortcut(QKeySequence(shortcut))
        a.triggered.connect(fn)
        return a

    # ── Signal wiring ──────────────────────────────────────────────────────────

    def _wire_signals(self):
        s = self._sigs
        s.rx_msg.connect(self._on_rx)
        s.rx_err.connect(lambda m: self._log_sys(m, C["amber"]))
        s.rssi.connect(self._on_rssi)
        s.tx_start.connect(self._on_tx_start)
        s.tx_done.connect(self._on_tx_done)
        s.lbt_busy.connect(lambda: self._log_sys("** CH BUSY (LBT) **", C["amber"]))
        s.dbg.connect(self._on_dbg)
        s.connected.connect(self._on_connect)
        s.disconnected.connect(self._on_disconnect)
        s.ping_rtt.connect(lambda ms: self._sb_rtt.setText(f"RTT:{ms:.0f}ms"))
        s.ack.connect(self._on_ack)
        s.retry.connect(self._on_retry)
        s.fail.connect(self._on_fail)
        s.status.connect(self._on_status)
        s.emcon_chg.connect(self._on_emcon_evt)
        s.beacon_chg.connect(self._on_beacon_evt)
        s.zeroized.connect(lambda: self._log_sys("!!! ARDUINO ZEROIZED !!!", C["red"]))

    def _wire_modem(self):
        m  = self._sigs
        md = self._modem

        def on_rx(data: dict):
            if data.get("is_dummy"): return
            seq = data["seq"]
            if seq in self._seen_seqs: return
            self._seen_seqs[seq] = None
            if len(self._seen_seqs) > 64:
                del self._seen_seqs[next(iter(self._seen_seqs))]
            result = self._crypto.decode_packet(data["payload"])
            if result:
                src, dst, body = result
                data["src"] = src; data["dst"] = dst; data["body"] = body
                m.rx_msg.emit(data)
            else:
                m.rx_err.emit(f"** RX SEQ={data['seq']:04X}: COMSEC AUTH FAIL **")

        md.on(EVT_RX,         on_rx)
        md.on(EVT_RSSI,       lambda v: m.rssi.emit(v))
        md.on(EVT_TXSTART,    lambda v: m.tx_start.emit(v))
        md.on(EVT_TXDONE,     lambda _: m.tx_done.emit())
        md.on(EVT_LBT_BUSY,   lambda _: m.lbt_busy.emit())
        md.on(EVT_DBG,        lambda t: m.dbg.emit(t))
        md.on(EVT_CONNECT,    lambda p: m.connected.emit(p))
        md.on(EVT_DISCONNECT, lambda _: m.disconnected.emit())
        md.on(EVT_ACK,        lambda v: m.ack.emit(v))
        md.on(EVT_RETRY,      lambda v: m.retry.emit(v))
        md.on(EVT_FAIL,       lambda v: m.fail.emit(v))
        md.on(EVT_STATUS,     lambda v: m.status.emit(v))
        md.on(EVT_EMCON,      lambda v: m.emcon_chg.emit(v))
        md.on(EVT_BEACON,     lambda v: m.beacon_chg.emit(v))
        md.on(EVT_ZEROIZED,   lambda _: m.zeroized.emit())
        md.on(EVT_PONG,       lambda _: m.ping_rtt.emit(
            (time.monotonic() - self._ping_t) * 1000))
        md.on(EVT_READY,      lambda _: self._apply_modem())
        self._gps.add_callback(lambda _: None)   # GPS running, not displayed
        md.start()

    def _apply_modem(self):
        try: net = int(self._settings.get("net_id","CD"), 16)
        except ValueError: net = 0xCD
        self._modem.set_netid(net)
        self._modem.set_baud(self._settings.get("baud", 50))
        self._modem.set_emcon(self._emcon)
        self._modem.set_beacon(self._beacon)

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _on_rx(self, data: dict):
        dtg  = _dtg_now()
        src  = data.get("src","?")
        dst  = data.get("dst","?")
        body = data.get("body","")
        pri  = data.get("priority", 0)
        seq  = data.get("seq", 0)
        enc  = "ENC" if self._crypto.active else "CLR"
        self._append_msg(dtg, src, dst, body, enc, inbound=True, pri=pri, seq=seq)
        self._db.save(src, dst, body, data["payload"],
                      inbound=True, encrypted=self._crypto.active,
                      priority=pri, seq=seq)
        self._sb_seq.setText(f"SEQ:{seq:04X}")

    def _on_rssi(self, v: int):
        if v == self._last_rssi: return
        self._last_rssi = v
        filled = v // 10
        bar = "#" * filled + "-" * (10 - filled)
        col = C["green"] if v >= 60 else C["amber"] if v >= 30 else C["red"]
        self._sb_rssi.setText(f"SIG:[{bar}]")
        self._sb_rssi.setStyleSheet(f"color:{col};")

    def _on_tx_start(self, secs: int):
        self._tx_busy = True
        self._tx_btn.setEnabled(False)
        self._tx_btn.setText(f"~{secs}s")

    def _on_tx_done(self):
        self._tx_busy = False
        self._tx_btn.setEnabled(True)
        self._tx_btn.setText("TX")

    def _on_ack(self, seq: int):
        self._log_sys(f"++ ACK SEQ:{seq:04X}", C["green"])

    def _on_retry(self, data: dict):
        seq = data["seq"]; att = data["attempt"]
        self._log_sys(f"~~ RETRY {att}/{ARQ_RETRIES} SEQ:{seq:04X}", C["amber"])

    def _on_fail(self, seq: int):
        self._log_sys(f"!! FAIL SEQ:{seq:04X} — ALL RETRIES EXHAUSTED", C["red"])

    def _on_status(self, data: dict):
        if self._settings.get("show_dbg"):
            self._log_sys("STATUS: " + " ".join(f"{k}={v}" for k,v in data.items()), C["dim"])

    def _on_emcon_evt(self, active: bool):
        self._emcon = active
        self._emcon_act.setText("EMCON ON  [RX ONLY]" if active else "EMCON OFF")
        col = C["red"] if active else C["dim"]
        self._log_sys(
            "[!!] EMCON ACTIVE — TX SUPPRESSED" if active else "-- EMCON DEACTIVATED", col)

    def _on_beacon_evt(self, active: bool):
        self._beacon = active
        self._beacon_act.setText("BEACON ON  [SOS TX]" if active else "BEACON OFF")

    def _on_dbg(self, text: str):
        if self._settings.get("show_dbg"):
            self._log_sys(f"DBG:{text}", C["dim"])

    def _on_connect(self, port: str):
        self._hdr_modem.setText("[OK]")
        self._hdr_modem.setStyleSheet(f"color:{C['green']}; border:none;")
        self._sb_modem.setText(f"  MODEM: {port}")
        self._log_sys(f"++ MODEM ON {port}", C["green"])

    def _on_disconnect(self):
        self._hdr_modem.setText("[--]")
        self._hdr_modem.setStyleSheet(f"color:{C['red']}; border:none;")
        self._sb_modem.setText("  MODEM: OFFLINE")
        self._last_rssi = -1
        self._seen_seqs.clear()
        # Reset TX state — no TXDONE will arrive if modem dropped mid-transmission
        self._tx_busy = False
        self._tx_btn.setEnabled(True)
        self._tx_btn.setText("TX")
        self._log_sys("-- MODEM OFFLINE — RECONNECTING...", C["red"])

    # ── Typing preview ─────────────────────────────────────────────────────────

    def _on_text_changed(self, text: str):
        n = len(text)
        # Mirror the exact overhead calculation used in _send_message
        src      = self._settings.get("callsign","").strip().upper() or "ANON"
        dst      = self._dst.text().strip().upper() or "BROADCAST"
        cap      = MAX_PAYLOAD_PADDED if self._pad_chk.isChecked() else MAX_PAYLOAD
        overhead = len(src.encode()) + len(dst.encode()) + 2
        if self._crypto.active:
            overhead += self._crypto.OVERHEAD
        remaining = max(1, cap - overhead)
        col = C["green"] if n <= int(remaining * 0.8) else \
              C["amber"]  if n <= remaining            else C["red"]
        display = text[-60:] if len(text) > 60 else text
        self._preview.setText(display)
        self._preview.setStyleSheet(f"color:{col}; border:none;")
        self._char_count.setText(str(n))
        self._char_count.setStyleSheet(f"color:{col}; border:none;")

    # ── Actions ────────────────────────────────────────────────────────────────

    def _send_message(self):
        body = self._msg.text().strip()
        dst  = self._dst.text().strip().upper() or "BROADCAST"
        if not body: return
        if self._tx_busy:
            self._log_sys("** TX BUSY **", C["amber"]); return
        if not self._modem.connected:
            self._log_sys("** MODEM OFFLINE **", C["red"]); return
        if self._emcon:
            self._log_sys("** EMCON ACTIVE **", C["red"]); return

        src  = self._settings.get("callsign","").strip().upper() or "ANON"
        padded   = self._pad_chk.isChecked()
        ack_req  = self._ack_chk.isChecked()
        capacity = MAX_PAYLOAD_PADDED if padded else MAX_PAYLOAD
        overhead = len(src.encode()) + len(dst.encode()) + 2
        if self._crypto.active: overhead += self._crypto.OVERHEAD
        if len(body.encode()) > capacity - overhead:
            self._log_sys(f"** MSG TOO LONG **", C["red"]); return

        payload = self._crypto.encode_packet(src, dst, body)
        flags   = make_txopt(priority=0, ack_req=ack_req, padded=padded)
        self._modem.send_tx(payload, flags=flags)

        dtg = _dtg_now(); enc = "ENC" if self._crypto.active else "CLR"
        self._append_msg(dtg, src, dst, body, enc, inbound=False, pri=0, seq=0)
        self._db.save(src, dst, body, payload, inbound=False,
                      encrypted=self._crypto.active, priority=0, seq=0)
        self._msg.clear()   # clears preview too via textChanged

    def _insert_template(self, text: str):
        self._msg.setText(text)
        self._msg.setFocus()
        self._msg.end(False)

    def _toggle_emcon(self):
        self._modem.set_emcon(not self._emcon)

    def _toggle_beacon(self):
        self._modem.set_beacon(not self._beacon)

    def _do_ping(self):
        if not self._modem.connected: return
        self._ping_t = time.monotonic()
        self._modem.send_ping()

    def _clear_log(self): self._chat.clear()

    def _do_zeroize(self):
        dlg = ZeroizeDialog(self)
        _, _, fs, *_ = _PROFILES[self._profile]
        dlg.setStyleSheet(_style(fs))
        if dlg.exec_() != QDialog.Accepted: return
        self._modem.zeroize()
        self._crypto.clear()
        try: os.remove(KEY_FILE)
        except FileNotFoundError: pass
        self._seen_seqs.clear()
        self._hdr_comsec.setText("NO KEY")
        self._hdr_comsec.setStyleSheet(f"color:{C['red']}; border:none;")
        self._log_sys(
            "!!! ZEROIZE COMPLETE — KEY WIPED — RESTART TO RELOAD COMSEC", C["red"])

    def _open_settings(self):
        _, _, fs, *_ = _PROFILES[self._profile]
        dlg = SettingsDialog(self._settings, self)
        dlg.setStyleSheet(_style(fs))
        if dlg.exec_() == QDialog.Accepted:
            self._settings.update(dlg.get_settings())
            self._save_settings()
            if self._modem.connected:
                self._apply_modem()

    # ── Message rendering ──────────────────────────────────────────────────────

    def _insert_html(self, html: str):
        c  = self._chat
        tc = c.textCursor()
        tc.movePosition(QTextCursor.End)
        c.setTextCursor(tc)
        c.insertHtml(html)
        c.verticalScrollBar().setValue(c.verticalScrollBar().maximum())

    def _append_msg(self, dtg, src, dst, body, enc_tag,
                    inbound, pri=0, seq=None):
        bg    = C["other_bg"] if inbound else C["self_bg"]
        arrow = "<<" if inbound else ">>"
        pc    = PRI_COLOURS.get(pri, C["routine"])
        seq_s = f"{seq:04X}" if seq is not None else "----"
        # Header: direction · from → to · dtg · seq · enc
        hdr = (
            f'<span style="color:{C["dim"]};">'
            f'{_he(src)}{arrow}{_he(dst)}  {_he(dtg)}  '
            f'SEQ:{seq_s} [{enc_tag}]'
            f'</span>'
        )
        body_html = (
            f'<span style="color:{C["white"]}; font-weight:bold;">'
            f'{_he(body)}</span>'
        )
        self._insert_html(
            f'<div style="background:{bg}; padding:2px 6px; margin:1px 0;'
            f' border-left:2px solid {pc};">'
            f'<span style="font-family:Monospace; font-size:8px;">{hdr}</span>'
            f'<br>'
            f'<span style="font-family:Monospace; font-size:10px;">{body_html}</span>'
            f'</div>'
        )

    def _log_sys(self, text: str, colour: str = ""):
        col   = colour or C["dim"]
        lines = _he(text).replace("\n", "<br>")
        self._insert_html(
            f'<div style="padding:1px 6px;">'
            f'<span style="color:{col}; font-family:Monospace; font-size:8px;">'
            f'{lines}</span></div>'
        )

    def _load_history(self):
        rows = self._db.load_recent(80)
        if not rows: return
        self._chat.setUpdatesEnabled(False)
        try:
            for row in rows:
                dtg = _dtg_ts(row["ts"]); enc = "ENC" if row["encrypted"] else "CLR"
                self._append_msg(dtg, row["src"], row["dst"], row["body"],
                                  enc, row["inbound"],
                                  pri=row["priority"], seq=row["seq"])
        finally:
            self._chat.setUpdatesEnabled(True)
        self._chat.verticalScrollBar().setValue(
            self._chat.verticalScrollBar().maximum())
        self._log_sys(f"-- {len(rows)} MSGS IN LOG --")

    # ── Timers ─────────────────────────────────────────────────────────────────

    def _start_timers(self):
        self._clock_timer = QTimer(self)
        self._clock_timer.setInterval(1000)
        self._clock_timer.timeout.connect(
            lambda: self._hdr_clock.setText(_zulu()))
        self._clock_timer.start()
        self._hdr_clock.setText(_zulu())

        self._ping_timer = QTimer(self)
        self._ping_timer.setInterval(15_000)
        self._ping_timer.timeout.connect(self._do_ping)
        self._ping_timer.start()

    # ── Keyboard — Morse key on Spacebar ──────────────────────────────────────

    def keyPressEvent(self, ev):
        if ev.key() == Qt.Key_Space and not ev.isAutoRepeat():
            if not self._msg.hasFocus():
                if not self._morse_down:
                    self._morse_down = True
                    self._modem.send_key(True)
                return
        super().keyPressEvent(ev)

    def keyReleaseEvent(self, ev):
        if ev.key() == Qt.Key_Space and not ev.isAutoRepeat():
            if self._morse_down:
                self._morse_down = False
                self._modem.send_key(False)
            return
        super().keyReleaseEvent(ev)

    # ── Shutdown ───────────────────────────────────────────────────────────────

    def closeEvent(self, ev):
        self._clock_timer.stop()
        self._ping_timer.stop()
        self._modem.stop()
        self._gps.stop()
        self._save_settings()
        ev.accept()


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description="Cyberdeck Milcomms v9")
    p.add_argument("--port",    help="Serial port override")
    p.add_argument("--reset",   action="store_true",
                   help="Delete settings and key file, then exit")
    p.add_argument("--display", choices=["full","5inch","35inch"],
                   help="Force display profile (default: auto from screen width)")
    args = p.parse_args()

    if args.reset:
        for f in [SETTINGS_FILE, KEY_FILE]:
            try:    os.remove(f); print(f"Deleted: {f}")
            except FileNotFoundError: print(f"Not found: {f}")
        sys.exit(0)

    app = QApplication(sys.argv)
    app.setApplicationName("Cyberdeck v9")
    app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps,    True)
    if not args.display:
        args.display = _detect_profile(None)
    log.info(f"Display profile: {args.display}")
    MainWindow(args)
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
