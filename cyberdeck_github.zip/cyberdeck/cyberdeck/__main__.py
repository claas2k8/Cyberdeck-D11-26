"""Entry point for  python -m cyberdeck  and the  cyberdeck  console script."""
from cyberdeck.app import main

if __name__ == "__main__":
    main()
