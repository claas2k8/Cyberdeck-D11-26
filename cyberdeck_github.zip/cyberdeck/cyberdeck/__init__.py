"""Cyberdeck Military Comms Suite — PMR446 encrypted radio messenger."""
__version__ = "9.0.0"
