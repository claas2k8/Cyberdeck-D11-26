"""
serial_modem.py — Arduino serial bridge for Cyberdeck v7
Parses all v7 protocol messages. Thread-safe, auto-reconnects.

New in v7:
  RX format: RX:<flags_hex>:<seq_hex4>:<payload_hex>
  New events: EVT_ACK, EVT_RETRY, EVT_FAIL, EVT_STATUS, EVT_EMCON, EVT_BEACON
  New commands: set_baud, set_netid, set_emcon, set_beacon, set_dummy,
                set_jitter, request_status
  send_tx(payload, flags): single-command TX using TX:<flags2>:<hex> format (v7.3+)
"""

import threading
import time
import serial
import logging

log = logging.getLogger("modem")

# ── events ────────────────────────────────────────────────────────────────────
EVT_READY      = "ready"
EVT_RX         = "rx"          # dict: {flags, seq, payload(bytes), priority, ack_req,
                                #        is_dummy, padded}
EVT_RSSI       = "rssi"        # int: 0–100
EVT_TXSTART    = "txstart"     # int: estimated seconds
EVT_TXDONE     = "txdone"
EVT_LBT_BUSY   = "lbt_busy"
EVT_DBG        = "dbg"         # str
EVT_CONNECT    = "connect"     # str: port
EVT_DISCONNECT = "disconnect"
EVT_PONG       = "pong"
EVT_ACK        = "ack"         # int: seq number acknowledged
EVT_RETRY      = "retry"       # dict: {seq, attempt}
EVT_FAIL       = "fail"        # int: seq number that failed all retries
EVT_STATUS     = "status"      # dict: parsed key=value pairs
EVT_EMCON      = "emcon"       # bool: emcon state
EVT_BEACON     = "beacon"      # bool: beacon state
EVT_ZEROIZED   = "zeroized"    # no data — Arduino confirmed zeroize

# ── FLAGS byte bit masks (mirrors firmware) ───────────────────────────────────
F_PRI_MASK  = 0xC0
F_PRI_SHIFT = 6
F_ACK_REQ   = 0x20
F_IS_ACK    = 0x10
F_IS_DUMMY  = 0x08
F_PADDED    = 0x04

PRI_NAMES = {0: "ROUTINE", 1: "PRIORITY", 2: "IMMEDIATE", 3: "FLASH"}


def make_txopt(priority: int = 0, ack_req: bool = False,
               padded: bool = False) -> int:
    """Build a FLAGS byte for use with send_tx(payload, flags=...)."""
    flags = (priority & 0x03) << F_PRI_SHIFT
    if ack_req: flags |= F_ACK_REQ
    if padded:  flags |= F_PADDED
    return flags


class SerialModem:
    def __init__(self, port: str = "/dev/ttyACM0", baud: int = 9600,
                 reconnect: bool = True):
        self._port      = port
        self._baud      = baud
        self._reconnect = reconnect
        self._ser       = None
        self._running   = False
        self._lock      = threading.Lock()
        self._callbacks: dict[str, list] = {}
        self._thread    = None
        self._connected = False

    # ── public API ────────────────────────────────────────────────────────────

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True,
                                         name="modem-reader")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._ser and self._ser.is_open:
            try: self._ser.close()
            except Exception: pass
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=4.0)  # wait up to 4s for clean exit

    # ── TX / control commands ─────────────────────────────────────────────────

    def send_tx(self, payload: bytes, flags: int = 0):
        """
        Transmit payload bytes with a flags byte.
        Firmware protocol (v7.3+): TX:<flags_hex2>:<payload_hex>
        flags=00 means no options (ROUTINE priority, no ACK, no padding).
        """
        self._writeln(f"TX:{flags:02X}:{payload.hex().upper()}")

    def send_ping(self):
        self._writeln("PING")

    def send_key(self, down: bool):
        self._writeln("KEY:1" if down else "KEY:0")

    def set_baud(self, baud: int):
        """Set RTTY baud rate: 50 or 100."""
        if baud not in (50, 100):
            raise ValueError(f"Unsupported baud rate {baud}: must be 50 or 100")
        self._writeln(f"BAUD:{baud}")

    def set_netid(self, net_id: int):
        """Set 1-byte net ID (0x00–0xFF). Both nodes must match."""
        self._writeln(f"NETID:{net_id:02X}")

    def set_emcon(self, active: bool):
        """Enable/disable emission control (receive-only mode)."""
        self._writeln("EMCON:1" if active else "EMCON:0")

    def set_beacon(self, active: bool):
        """Enable/disable CW distress beacon."""
        self._writeln("BEACON:1" if active else "BEACON:0")

    def set_dummy(self, active: bool):
        """Enable/disable dummy traffic."""
        self._writeln("DUMMY:1" if active else "DUMMY:0")

    def set_jitter(self, active: bool):
        """Enable/disable TX jitter (TRANSEC)."""
        self._writeln("JITTER:1" if active else "JITTER:0")

    def zeroize(self):
        """Emergency: reset all Arduino operational state immediately."""
        self._writeln("ZEROIZE")

    def request_status(self):
        """Request a STATUS dump from the Arduino."""
        self._writeln("STATUS")

    # ── event bus ─────────────────────────────────────────────────────────────

    def on(self, event: str, callback):
        with self._lock:
            self._callbacks.setdefault(event, []).append(callback)

    def off(self, event: str, callback):
        with self._lock:
            if event in self._callbacks:
                try: self._callbacks[event].remove(callback)
                except ValueError: pass

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def port(self) -> str:
        return self._port

    # ── internal ──────────────────────────────────────────────────────────────

    def _emit(self, event: str, data=None):
        with self._lock:
            cbs = list(self._callbacks.get(event, []))
        for cb in cbs:
            try: cb(data)
            except Exception as e:
                log.error(f"Callback [{event}]: {e}")

    def _writeln(self, text: str):
        if self._ser and self._ser.is_open:
            try:
                self._ser.write((text + "\n").encode())
                self._ser.flush()
            except serial.SerialException as e:
                log.warning(f"Write failed: {e}")
        else:
            log.debug(f"Write skipped (disconnected): {text}")

    def _connect(self) -> bool:
        try:
            self._ser = serial.Serial(
                port          = self._port,
                baudrate      = self._baud,
                timeout       = 1.0,
                write_timeout = 2.0,
            )
            self._ser.dtr = False
            time.sleep(0.1)
            self._ser.dtr = True
            self._ser.flushInput()
            self._connected = True
            self._emit(EVT_CONNECT, self._port)
            log.info(f"Connected: {self._port}")
            return True
        except serial.SerialException as e:
            log.debug(f"Connect failed: {e}")
            return False

    def _parse_line(self, line: str):
        line = line.strip()
        if not line:
            return

        if line == "READY":
            self._emit(EVT_READY)

        elif line == "PONG":
            self._emit(EVT_PONG)

        elif line.startswith("RX:"):
            # Format: RX:<flags_hex>:<seq_hex4>:<payload_hex>
            try:
                parts = line[3:].split(":", 2)
                if len(parts) != 3:
                    log.warning(f"Bad RX format: {line!r}")
                    return
                flags   = int(parts[0], 16)
                seq     = int(parts[1], 16)
                payload = bytes.fromhex(parts[2]) if parts[2] else b""
                self._emit(EVT_RX, {
                    "flags":    flags,
                    "seq":      seq,
                    "payload":  payload,
                    "priority": (flags & F_PRI_MASK) >> F_PRI_SHIFT,
                    "ack_req":  bool(flags & F_ACK_REQ),
                    "is_dummy": bool(flags & F_IS_DUMMY),
                    "padded":   bool(flags & F_PADDED),
                })
            except (ValueError, IndexError) as e:
                log.warning(f"RX parse error: {e} — {line!r}")

        elif line.startswith("RSSI:"):
            try: self._emit(EVT_RSSI, int(line[5:]))
            except ValueError: pass

        elif line.startswith("TXSTART:"):
            try: self._emit(EVT_TXSTART, int(line[8:]))
            except ValueError: pass

        elif line == "TXDONE":
            self._emit(EVT_TXDONE)

        elif line.startswith("ACK:"):
            try: self._emit(EVT_ACK, int(line[4:], 16))
            except ValueError: pass

        elif line.startswith("RETRY:"):
            # Format: RETRY:<seq_hex4>:<attempt>
            try:
                parts = line[6:].split(":", 1)
                self._emit(EVT_RETRY, {"seq": int(parts[0], 16),
                                       "attempt": int(parts[1])})
            except (ValueError, IndexError): pass

        elif line.startswith("FAIL:"):
            try: self._emit(EVT_FAIL, int(line[5:], 16))
            except ValueError: pass

        elif line.startswith("STATUS:"):
            # Format: STATUS:key=val;key=val;…
            pairs = {}
            for item in line[7:].split(";"):
                if "=" in item:
                    k, _, v = item.partition("=")
                    pairs[k.strip()] = v.strip()
            self._emit(EVT_STATUS, pairs)

        elif line == "LBT:BUSY":
            self._emit(EVT_LBT_BUSY)

        elif line == "EMCON:ON":
            self._emit(EVT_EMCON, True)
        elif line == "EMCON:OFF":
            self._emit(EVT_EMCON, False)
        elif line == "BEACON:ON":
            self._emit(EVT_BEACON, True)
        elif line == "BEACON:OFF":
            self._emit(EVT_BEACON, False)

        elif line == "ZEROIZED":
            self._emit(EVT_ZEROIZED)

        elif line.startswith("DBG:"):
            log.debug(f"Arduino: {line[4:]}")
            self._emit(EVT_DBG, line[4:])

        else:
            log.debug(f"Unknown: {line!r}")

    def _run(self):
        while self._running:
            if not self._connect():
                if self._reconnect:
                    time.sleep(3); continue
                else:
                    break
            try:
                while self._running:
                    raw = self._ser.readline()
                    if raw:
                        try:
                            self._parse_line(raw.decode("utf-8", errors="replace"))
                        except Exception as e:
                            log.error(f"Parse error: {e}")
            except serial.SerialException as e:
                log.warning(f"Serial error: {e}")
            finally:
                self._connected = False
                try: self._ser.close()
                except Exception: pass
                self._emit(EVT_DISCONNECT)
                if self._reconnect and self._running:
                    log.info("Reconnecting in 3s…")
                    time.sleep(3)
                else:
                    break
