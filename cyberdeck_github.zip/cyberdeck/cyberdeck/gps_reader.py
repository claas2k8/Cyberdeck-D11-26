"""
gps_reader.py — GY-NEO6MV2 NMEA reader for Cyberdeck
Hardware: Pi pin 10 (GPIO15 / UART RX) ← GY TX
Port: /dev/ttyAMA0, 9600 baud

.fix             → dict or None
                   Keys: valid(bool), time(str), date(str),
                         lat(float), lon(float), alt(float),
                         sats(int), age(float)
.is_connected    → bool
.start()         → bool
.stop()
.add_callback(fn)  fn(fix_dict) called from reader thread
"""

import threading
import time
import logging

log = logging.getLogger("gps")

GPS_PORT  = "/dev/ttyAMA0"
GPS_BAUD  = 9600
GPS_TIMEOUT = 2.0

# Attempt imports — graceful degradation if libraries missing
try:
    import serial as _serial
    _HAVE_SERIAL = True
except ImportError:
    _HAVE_SERIAL = False
    log.warning("pyserial not available — GPS disabled")

try:
    import pynmea2 as _pynmea2
    _HAVE_PYNMEA = True
except ImportError:
    _HAVE_PYNMEA = False
    log.warning("pynmea2 not available — GPS disabled")


class GpsReader:
    def __init__(self, port: str = GPS_PORT, baud: int = GPS_BAUD):
        self._port      = port
        self._baud      = baud
        self._fix       = None
        self._fix_time  = 0.0
        self._rmc_time  = 0.0   # time of last valid RMC — age counts from here only
        self._callbacks = []
        self._lock      = threading.Lock()
        self._thread    = None
        self._running   = False
        self._connected = False

    # ── public API ────────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not _HAVE_SERIAL or not _HAVE_PYNMEA:
            log.warning("GPS start skipped: missing dependencies")
            return False
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True,
                                         name="gps-reader")
        self._thread.start()
        return True

    def stop(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=4.0)  # readline timeout=2s + error sleep=5s; 4s covers most cases

    def add_callback(self, fn):
        with self._lock:
            self._callbacks.append(fn)

    def remove_callback(self, fn):
        with self._lock:
            try: self._callbacks.remove(fn)
            except ValueError: pass

    @property
    def fix(self) -> dict | None:
        with self._lock:
            return dict(self._fix) if self._fix else None

    @property
    def is_connected(self) -> bool:
        return self._connected

    # ── internal ──────────────────────────────────────────────────────────────

    def _emit(self, fix: dict):
        with self._lock:
            self._fix      = fix
            self._fix_time = time.monotonic()
            cbs = list(self._callbacks)
        for cb in cbs:
            try: cb(dict(fix))
            except Exception as e: log.error(f"GPS callback error: {e}")

    def _parse_gprmc(self, msg) -> dict | None:
        """Parse GPRMC sentence."""
        try:
            if not msg.is_valid:
                return None
            # pynmea2 GPRMC attributes
            t = msg.timestamp  # datetime.time
            d = msg.datestamp  # datetime.date
            return {
                "valid": True,
                "time":  t.strftime("%H:%M:%S") + " UTC",
                "date":  d.strftime("%d/%m/%Y"),
                "lat":   float(msg.latitude),
                "lon":   float(msg.longitude),
                "alt":   0.0,   # filled by GPGGA
                "sats":  0,
                "age":   0.0,
            }
        except Exception as e:
            log.debug(f"GPRMC parse: {e}")
            return None

    def _parse_gpgga(self, msg) -> dict | None:
        """Parse GPGGA sentence for altitude and satellites."""
        try:
            if int(msg.gps_qual) == 0:
                return None
            return {
                "valid": True,
                "time":  msg.timestamp.strftime("%H:%M:%S") + " UTC",
                "date":  "",          # GGA has no date
                "lat":   float(msg.latitude),
                "lon":   float(msg.longitude),
                "alt":   float(msg.altitude),
                "sats":  int(msg.num_sats),
                "age":   0.0,
            }
        except Exception as e:
            log.debug(f"GPGGA parse: {e}")
            return None

    def _run(self):
        last_fix: dict | None = None

        while self._running:
            try:
                with _serial.Serial(self._port, self._baud,
                                    timeout=GPS_TIMEOUT) as ser:
                    self._connected = True
                    log.info(f"GPS opened: {self._port}")

                    while self._running:
                        raw = ser.readline()
                        if not raw:
                            continue
                        try:
                            line = raw.decode("ascii", errors="replace").strip()
                        except Exception:
                            continue

                        try:
                            msg = _pynmea2.parse(line)
                        except _pynmea2.ParseError:
                            continue

                        fix = None
                        if isinstance(msg, _pynmea2.types.talker.RMC):
                            fix = self._parse_gprmc(msg)
                        if isinstance(msg, _pynmea2.types.talker.GGA):
                            gga = self._parse_gpgga(msg)
                            if gga and last_fix:
                                # Build a fresh dict so readers via self.fix
                                # never see a half-merged state.
                                # Do NOT update _rmc_time — age tracks RMC freshness.
                                merged = dict(last_fix)
                                merged["alt"]  = gga["alt"]
                                merged["sats"] = gga["sats"]
                                last_fix = merged
                                self._emit(last_fix)
                            continue

                        if fix:
                            last_fix = fix
                            fix["age"] = 0.0
                            self._rmc_time = time.monotonic()  # RMC-only timestamp
                            self._emit(fix)

                        # Stale-age update: counts seconds since last valid RMC,
                        # not since last GGA emit (so age accurately reflects GPS health)
                        if last_fix is not None and self._rmc_time > 0:
                            last_fix["age"] = time.monotonic() - self._rmc_time

            except Exception as e:
                log.warning(f"GPS error: {e}")
                self._connected = False
                if self._running:
                    time.sleep(5)

        self._connected = False
        log.info("GPS reader stopped")
