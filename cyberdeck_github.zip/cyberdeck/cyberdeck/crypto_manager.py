"""
crypto_manager.py — ChaCha20-Poly1305 encryption for Cyberdeck
Wire format: nonce(12) || ciphertext || tag(16)
Key derivation: PBKDF2-HMAC-SHA256, 200 000 rounds

SALT DESIGN
-----------
Both radio nodes must derive the SAME key from the SAME passphrase.
A per-device random salt (the previous design) produced a different
key on each node even if both used identical passphrases, so encrypted
communication was impossible without manually copying the salt file.

For a PSK (pre-shared key) radio system the correct model is a fixed
application salt.  The passphrase entropy is the security parameter;
the fixed salt provides domain separation (different keys for the same
passphrase in different applications) without breaking key agreement.

Blank passphrase → plaintext mode.
Passphrase is NEVER written to disk.
"""

import os
import logging

log = logging.getLogger("crypto")

PBKDF2_ROUNDS = 200_000
PBKDF2_DKLEN  = 32      # 256-bit ChaCha20 key
NONCE_LEN     = 12
TAG_LEN       = 16

# Fixed application salt — ASCII text encoded as hex, identical on every node.
# Purpose: domain separation (same passphrase in a different app derives a
# different key).  Passphrase entropy via 200 000 PBKDF2 rounds is the actual
# security parameter; the salt does not need to be secret or random.
_APP_SALT = bytes.fromhex(
    "4379626572646563"   # "Cyberdec"
    "6b5f4d696c636f6d"   # "k_Milcom"
    "6d735f53616c745f"   # "ms_Salt_"
    "76375f323032350a"   # "v7_2025\n"
)

# ── optional: use pycryptodome if available ───────────────────────────────────
try:
    from Crypto.Cipher import ChaCha20_Poly1305 as _CC20
    _HAVE_CRYPTO = True
    log.debug("Using pycryptodome ChaCha20-Poly1305")
except ImportError:
    _HAVE_CRYPTO = False
    log.warning("pycryptodome not found — falling back to plaintext mode")


class CryptoManager:
    # Bytes added by encryption (nonce + tag) — used for message length budget
    OVERHEAD = NONCE_LEN + TAG_LEN   # 28

    def __init__(self):
        self._key: bytes | None = None

    # ── passphrase management ─────────────────────────────────────────────────

    def set_passphrase(self, passphrase: str):
        """
        Derive and activate key from passphrase.
        Both nodes must call this with the same passphrase to communicate.
        No file I/O — nothing is written to disk.
        Blank passphrase → plaintext mode.
        """
        if not passphrase:
            self._key = None
            log.info("Crypto: plaintext mode")
            return
        if not _HAVE_CRYPTO:
            self._key = None
            log.warning("Crypto: pycryptodome missing, forced plaintext")
            return
        self._key = self._derive(passphrase)
        log.info("Crypto: key derived (never written to disk)")

    def load_passphrase(self, passphrase: str) -> bool:
        """
        Alias for set_passphrase — kept for API compatibility.
        Returns True on success, False if pycryptodome unavailable.
        """
        self.set_passphrase(passphrase)
        return _HAVE_CRYPTO or not passphrase

    def clear(self):
        self._key = None

    @property
    def active(self) -> bool:
        return self._key is not None and _HAVE_CRYPTO

    # ── encrypt / decrypt ─────────────────────────────────────────────────────

    def encrypt(self, plaintext: bytes) -> bytes:
        if not self.active:
            return plaintext
        nonce  = os.urandom(NONCE_LEN)
        cipher = _CC20.new(key=self._key, nonce=nonce)
        ct, tag = cipher.encrypt_and_digest(plaintext)
        return nonce + ct + tag

    def decrypt(self, data: bytes) -> bytes | None:
        if not self.active:
            return data
        if len(data) < NONCE_LEN + TAG_LEN:
            log.warning("Decrypt: payload too short")
            return None
        nonce = data[:NONCE_LEN]
        tag   = data[-TAG_LEN:]
        ct    = data[NONCE_LEN:-TAG_LEN]
        try:
            cipher = _CC20.new(key=self._key, nonce=nonce)
            return cipher.decrypt_and_verify(ct, tag)
        except Exception:
            log.warning("Decrypt: authentication failed (wrong passphrase or corrupt packet)")
            return None

    # ── packet encode / decode ────────────────────────────────────────────────
    #
    # Wire payload (before encryption): src\x00dst\x00body  (UTF-8)

    def encode_packet(self, src: str, dst: str, body: str) -> bytes:
        plain = (src + "\x00" + dst + "\x00" + body).encode("utf-8")
        return self.encrypt(plain)

    def decode_packet(self, data: bytes) -> tuple[str, str, str] | None:
        plain = self.decrypt(data)
        if plain is None:
            return None
        try:
            parts = plain.decode("utf-8").split("\x00", 2)
            if len(parts) != 3:
                log.warning("Packet decode: bad structure")
                return None
            return parts[0], parts[1], parts[2]
        except Exception as e:
            log.warning(f"Packet decode error: {e}")
            return None

    # ── internals ─────────────────────────────────────────────────────────────

    @staticmethod
    def _derive(passphrase: str) -> bytes:
        import hashlib
        return hashlib.pbkdf2_hmac(
            "sha256", passphrase.encode(), _APP_SALT,
            PBKDF2_ROUNDS, dklen=PBKDF2_DKLEN
        )
